# PANTALLA DE CLIENTE -- CUSTOMER DISPLAY

## Características


Descripción del módulo en español...


Consiste en una funcionalidad que permite mostrar al cliente una pantalla o vista de la compra que esta realizando, mostrando la lista de los produtos, sus cantidades, descuentos y precios, despliega además los montos totales a pagar. La pantalla permite configurar imágenes promocionales de nuestro negocio para que el cliente las observe mientras espera que termine el pago.

English Description
## Features
It consists of a functionality that allows the customer to be shown a screen or view of the purchase they are making, showing the list of products, their quantities, discounts and prices, as well as displaying the total amounts to be paid. The screen allows you to configure promotional images of our business so that the customer can see them while waiting for the payment to finish.


<!--

## Installation

### From the ZIP file and GUI interface

- If you get the module in a zip file (like when downloading it from the market place [Dolistore](https://www.dolistore.com)), go into
menu ```Home - Setup - Modules - Deploy external module``` and upload the zip file.

Note: If this screen tell you there is no custom directory, check your setup is correct:

- In your Dolibarr installation directory, edit the ```htdocs/conf/conf.php``` file and check that following lines are not commented:

    ```php
    //$dolibarr_main_url_root_alt ...
    //$dolibarr_main_document_root_alt ...
    ```

- Uncomment them if necessary (delete the leading ```//```) and assign a sensible value according to your Dolibarr installation

    For example :

    - UNIX:
        ```php
        $dolibarr_main_url_root_alt = '/custom';
        $dolibarr_main_document_root_alt = '/var/www/Dolibarr/htdocs/custom';
        ```

    - Windows:
        ```php
        $dolibarr_main_url_root_alt = '/custom';
        $dolibarr_main_document_root_alt = 'C:/My Web Sites/Dolibarr/htdocs/custom';
        ```

### From a GIT repository

- Clone the repository in ```$dolibarr_main_document_root_alt/customerdisplay```

```sh
cd ....../custom
git clone git@github.com:gitlogin/customerdisplay.git customerdisplay
```

### <a name="final_steps"></a>Final steps

From your browser:

  - Log into Dolibarr as a super-administrator
  - Go to "Setup" -> "Modules"
  - You should now be able to find and enable the module

-->

## Licencia (License)

GPLv3.

## Contacto (contact)

Español : Necesita una mejora a este módulo? o ayuda para adecuar su Dolibarr? contáctenos

English : Need an upgrade to this module? or help to adjust your Dolibarr? Contact Us

Italiano: Hai bisogno di un aggiornamento a questo modulo? o aiutare a regolare il tuo Dolibarr? Contattaci

<i class="fa fa-envelope-o"></i> <a href="mailto:codlines256@gmail.com">CodLines</a>
<br/>

<i class="fa fa-facebook-official"></i></i> <a target="_blank" href="https://www.facebook.com/profile.php?id=100078558251492">Facebook CodLines</a>
