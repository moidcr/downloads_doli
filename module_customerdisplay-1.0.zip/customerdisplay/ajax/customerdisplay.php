<?php
/* Copyright (C) 2001-2005 Rodolphe Quiedeville <rodolphe@quiedeville.org>
 * Copyright (C) 2004-2015 Laurent Destailleur  <eldy@users.sourceforge.net>
 * Copyright (C) 2005-2012 Regis Houssin        <regis.houssin@inodbox.com>
 * Copyright (C) 2015      Jean-François Ferry	<jfefe@aternatik.fr>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */



// Load Dolibarr environment
$res = 0;
// Try main.inc.php into web root known defined into CONTEXT_DOCUMENT_ROOT (not always defined)
if (!$res && !empty($_SERVER["CONTEXT_DOCUMENT_ROOT"])) $res = @include $_SERVER["CONTEXT_DOCUMENT_ROOT"]."/main.inc.php";
// Try main.inc.php into web root detected using web root calculated from SCRIPT_FILENAME
$tmp = empty($_SERVER['SCRIPT_FILENAME']) ? '' : $_SERVER['SCRIPT_FILENAME']; $tmp2 = realpath(__FILE__); $i = strlen($tmp) - 1; $j = strlen($tmp2) - 1;
while ($i > 0 && $j > 0 && isset($tmp[$i]) && isset($tmp2[$j]) && $tmp[$i] == $tmp2[$j]) { $i--; $j--; }
if (!$res && $i > 0 && file_exists(substr($tmp, 0, ($i + 1))."/main.inc.php")) $res = @include substr($tmp, 0, ($i + 1))."/main.inc.php";
if (!$res && $i > 0 && file_exists(dirname(substr($tmp, 0, ($i + 1)))."/main.inc.php")) $res = @include dirname(substr($tmp, 0, ($i + 1)))."/main.inc.php";
// Try main.inc.php using relative path
if (!$res && file_exists("../main.inc.php")) $res = @include "../main.inc.php";
if (!$res && file_exists("../../main.inc.php")) $res = @include "../../main.inc.php";
if (!$res && file_exists("../../../main.inc.php")) $res = @include "../../../main.inc.php";
if (!$res) die("Include of main fails");

include_once DOL_DOCUMENT_ROOT.'/compta/facture/class/facture.class.php';

/*echo "<pre>";
print_r($_POST);
exit;*/
// Get parameters
$action = GETPOST('action', 'aZ09');
$place = (GETPOST('place', 'aZ09') ? GETPOST('place', 'aZ09') : 0); // $place is id of table for Bar or Restaurant

$facid = GETPOST('facid', 'int');

if (empty($user->rights->takepos->run)) {
	accessforbidden();
}



if($action == "CheckTotals")
{
	$Resp = array();
	
	if ($place > 0) {
	$sql = "SELECT rowid FROM ".MAIN_DB_PREFIX."facture where ref='(PROV-POS".$db->escape($_SESSION["takeposterminal"]."-".$place).")'";
	$resql = $db->query($sql);
	$obj = $db->fetch_object($resql);
		if ($obj) {
			$facid = $obj->rowid;
		}
	}
	
	$object = new Facture($db);
	$object->fetch($facid);
	
	$totals = array(
		"Lines" => count($object->lines),
		"Tax" => price($object->total_tva, 1, '', 1, - 1, - 1, $conf->currency),
		"SubTotal" => price($object->total_ht, 1, '', 1, - 1, - 1, $conf->currency),
		"Total" => price($object->total_ttc, 1, '', 1, - 1, - 1, $conf->currency)
	);			
			
	if(isset($object->id) && isset($object->id))	
	{
			$Resp["Res"] = "Ok";
			$Resp["fact"] = $totals;
	}
	else	
	{
		$Resp["Res"] = "ErrorObj";
		$Resp["fact"] = "";
	}
	
	echo json_encode($Resp);
	exit;
}

if($action == "UploadImg")
{
	$Resp = array();
	if (is_array($_FILES)) {
		if (is_uploaded_file($_FILES['userImage']['tmp_name']))
		{
			$sourcePath = $_FILES['userImage']['tmp_name'];
	        $targetPath =  DOL_DOCUMENT_ROOT."/custom/customerdisplay/images/" . $_FILES['userImage']['name'];
	        if (!file_exists($targetPath))
	        {
		        if (move_uploaded_file($sourcePath, $targetPath))
		        {
		        	$linkPath =  "/custom/customerdisplay/images/" . $_FILES['userImage']['name'];
					// Insertion dans base de la ligne
					$sql = 'INSERT INTO customerdisplay_images';
					$sql .= ' (link, fk_user_author, datec, status';
					$sql .= ')';
					$sql .= " VALUES ('".$linkPath."', ";
					$sql .= " '".$user->id."', ";
					$sql .= " NOW(), ";
					$sql .= " 1 ";
					$sql .= ')';
				
					$resql = $db->query($sql);
					
					$Resp["Res"] = "OK";
					
		        	//$targetPath =  DOL_URL_ROOT."/custom/customerdisplay/images/" . $_FILES['userImage']['name'];
		         
		        }
				else
				{
					$Resp["Res"] = "No";
				}
			}
			else {
				$Resp["Res"] = "Exist";
			}
	    }
		else
		{
			$Resp["Res"] = "NoUp";
		}
	}
	else
	{
		$Resp["Res"] = "NoFil";
	}
	
	echo json_encode($Resp);
	exit;
}

if($action == "StImg")
{
	$imgid = GETPOST('imgid', 'int');
	$ck = GETPOST('ck', 'int');
	$Resp = array();
	if ($imgid) {
		$sqlu = "UPDATE customerdisplay_images";
		$sqlu .= " set status = '".$ck."' where rowid = '".$imgid ."'";
		
		if($db->query($sqlu))
		{
			$Resp["Res"] = "OK";
		}
		else
		{
			$Resp["Res"] = "No";
		}
	}
	else
	{
		$Resp["Res"] = "NoFil";
	}
	
	echo json_encode($Resp);
	exit;
}

if($action == "DelImg")
{
	$imgid = GETPOST('imgid', 'int');
	$Resp = array();
	if ($imgid) {
		$sql = 'SELECT link ';
		$sql .= ' FROM customerdisplay_images as t';
		$sql .= " where rowid = '".$imgid ."'";
		$resql = $db->query($sql);
		if ($resql) {
			$num = $db->num_rows($resql);
			$obj = $db->fetch_object($resql);
			if ($num) {
				$sqlu = "DELETE FROM customerdisplay_images";
				$sqlu .= " where rowid = '".$imgid ."'";
				
				if($db->query($sqlu))
				{
					$targetPath =  DOL_DOCUMENT_ROOT . $obj->link;
					unlink($targetPath);
					$Resp["Res"] = "OK";
				}
				else
				{
					$Resp["Res"] = "No";
				}
			}
			else
			{
				$Resp["Res"] = "No";
			}
		}
		else
		{
			$Resp["Res"] = "No";
		}
	}
	else
	{
		$Resp["Res"] = "NoFil";
	}
	
	echo json_encode($Resp);
	exit;
}