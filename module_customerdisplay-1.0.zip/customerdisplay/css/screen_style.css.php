<?php
/* Copyright (C) 2022 SuperAdmin
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

/**
 * \file    facturadian/css/facturadian.css.php
 * \ingroup facturadian
 * \brief   CSS file for module FacturaDian.
 */

//if (! defined('NOREQUIREUSER')) define('NOREQUIREUSER','1');	// Not disabled because need to load personalized language
//if (! defined('NOREQUIREDB'))   define('NOREQUIREDB','1');	// Not disabled. Language code is found on url.
if (!defined('NOREQUIRESOC')) {
	define('NOREQUIRESOC', '1');
}
//if (! defined('NOREQUIRETRAN')) define('NOREQUIRETRAN','1');	// Not disabled because need to do translations
if (!defined('NOCSRFCHECK')) {
	define('NOCSRFCHECK', 1);
}
if (!defined('NOTOKENRENEWAL')) {
	define('NOTOKENRENEWAL', 1);
}
if (!defined('NOLOGIN')) {
	define('NOLOGIN', 1); // File must be accessed by logon page so without login
}
//if (! defined('NOREQUIREMENU'))   define('NOREQUIREMENU',1);  // We need top menu content
if (!defined('NOREQUIREHTML')) {
	define('NOREQUIREHTML', 1);
}
if (!defined('NOREQUIREAJAX')) {
	define('NOREQUIREAJAX', '1');
}

session_cache_limiter('public');
// false or '' = keep cache instruction added by server
// 'public'  = remove cache instruction added by server
// and if no cache-control added later, a default cache delay (10800) will be added by PHP.

// Load Dolibarr environment
$res = 0;
// Try main.inc.php into web root known defined into CONTEXT_DOCUMENT_ROOT (not always defined)
if (!$res && !empty($_SERVER["CONTEXT_DOCUMENT_ROOT"])) {
	$res = @include $_SERVER["CONTEXT_DOCUMENT_ROOT"]."/main.inc.php";
}
// Try main.inc.php into web root detected using web root calculated from SCRIPT_FILENAME
$tmp = empty($_SERVER['SCRIPT_FILENAME']) ? '' : $_SERVER['SCRIPT_FILENAME']; $tmp2 = realpath(__FILE__); $i = strlen($tmp) - 1; $j = strlen($tmp2) - 1;
while ($i > 0 && $j > 0 && isset($tmp[$i]) && isset($tmp2[$j]) && $tmp[$i] == $tmp2[$j]) {
	$i--; $j--;
}
if (!$res && $i > 0 && file_exists(substr($tmp, 0, ($i + 1))."/main.inc.php")) {
	$res = @include substr($tmp, 0, ($i + 1))."/main.inc.php";
}
if (!$res && $i > 0 && file_exists(substr($tmp, 0, ($i + 1))."/../main.inc.php")) {
	$res = @include substr($tmp, 0, ($i + 1))."/../main.inc.php";
}
// Try main.inc.php using relative path
if (!$res && file_exists("../../main.inc.php")) {
	$res = @include "../../main.inc.php";
}
if (!$res && file_exists("../../../main.inc.php")) {
	$res = @include "../../../main.inc.php";
}
if (!$res) {
	die("Include of main fails");
}

require_once DOL_DOCUMENT_ROOT.'/core/lib/functions2.lib.php';

// Load user to have $user->conf loaded (not done by default here because of NOLOGIN constant defined) and load permission if we need to use them in CSS
/*if (empty($user->id) && ! empty($_SESSION['dol_login'])) {
	$user->fetch('',$_SESSION['dol_login']);
	$user->getrights();
}*/


// Define css type
header('Content-type: text/css');
// Important: Following code is to cache this file to avoid page request by browser at each Dolibarr page access.
// You can use CTRL+F5 to refresh your browser cache.
if (empty($dolibarr_nocache)) {
	header('Cache-Control: max-age=10800, public, must-revalidate');
} else {
	header('Cache-Control: no-cache');
}

?>

div.mainmenu.facturadian::before {
	content: "\f249";
}
div.mainmenu.facturadian {
	background-image: none;
}

.myclasscss {
	/* ... */
}



body,html{
     min-height:100% 
}
 body{
     font-family:"Source Sans Pro","Helvetica Neue",Helvetica,Arial,sans-serif 
}
 html, body {
     background: #EEEEEE;
     margin: 0;
     padding: 0;
     width: 100%;
     height: 100%;
     min-width: 400px;
     color: #333;
}
.wrap{
	background: #EEEEEE;
}
 a {
     outline: none;
}
 h2 {
     margin: 20px 0;
}
 .bill {
     min-height: 90vh;
     background: #FFF;
     margin: 20px 20px 0 20px;
}
 .content {
     display: none;
}
 .with-promo-space .wrap {
     margin: 0;
     padding: 0;
     padding-right: 480px;
     overflow: hidden;
}
 .with-promo-space .main {
     margin: 20px -500px 0 auto;
     width: 100%;
}
 .with-promo-space .content {
     display: block;
     padding-right: 40px;
}
 .with-promo-space .bill {
     width: 550px;
     float: left;
     min-height: 101vh;
}
 td {
     vertical-align: middle !important;
}
 #product-list {
     display: block;
     overflow: hidden;
     min-height: 80vh;
     border: 1px solid #ddd;
     padding: 20px 20px 0 20px;
}
 #totals {
     border-top: 1px solid #ddd;
}
 .preview_frame {
     width: 100%;
}
 @media print {
     .wrap {
         padding: 0;
         width: 100%;
         background: #FFF;
    }
     .main {
         display: none;
         margin: 0;
    }
     .bill {
         width: 90%;
         margin-left: auto;
         margin-right: auto;
         height: auto !important;
    }
     .bill, #product-list, #billTable {
         width: 100%;
         height: auto !important;
         min-height: 200px;
    }
     #billTable td {
         border-bottom: 1px solid #CCC;
    }
     #totals td {
         border: 1px solid #CCC !important;
         border-color: #CCC !important;
    }
}
 .ef-carousel {
     text-align: center;
     position: relative;
     max-width: 1280px;
     margin: 0 auto;
     overflow: hidden;
}
 .ef-carousel__state {
     display: none;
}
 .ef-carousel__next, .ef-carousel__prev {
     width: 30px;
     height: 30px;
     line-height: 28px;
     text-align: center;
     position: absolute;
     right: 10px;
     color: #000;
     background-color: #fff;
     opacity: 0.5;
     border-radius: 50%;
     top: 50%;
     margin-top: -20px;
     font-size: 24px;
     cursor: pointer;
     display: none;
     z-index: 1;
     transition: opacity 100ms linear;
}
 .ef-carousel__next:before, .ef-carousel__prev:before {
     content: '>';
}
 .ef-carousel__next:hover, .ef-carousel__prev:hover {
     opacity: 0.8;
}
 .ef-carousel__prev {
     right: auto;
     left: 10px;
}
 .ef-carousel__prev:before {
     content: '<';
}
 .ef-carousel__dot {
     cursor: pointer;
     width: 12px;
     height: 12px;
     display: inline-block;
     border-radius: 50%;
     background-color: rgba(0, 0, 0, 0.4);
}
 .ef-carousel__items {
     white-space: nowrap;
     font-size: 0;
     margin: 0 0 5px;
}
 .ef-carousel__item {
     max-width: 100%;
     vertical-align: top;
     display: inline-block;
     position: absolute;
     left: 0;
     top: 0;
     opacity: 0;
     transition: opacity 600ms linear;
}
 .ef-carousel__item:first-child {
     position: relative;
}
<?php
$sql = 'SELECT * ';
$sql .= ' FROM customerdisplay_images as t';
$resql = $db->query($sql);
if ($resql) {
	$num = $db->num_rows($resql);
	$i = 1;
	while ($i <= $num) {
		$obj = $db->fetch_object($resql);
		if ($obj) {?>
			
			 .ef-carousel__state:checked:nth-child(<?php echo $i ?>) ~ .ef-carousel__dot:nth-child(<?php echo $i ?>) {
			     background-color: rgba(0, 0, 0, 0.8);
			}
			
			 .ef-carousel__state:checked:nth-child(<?php echo $i ?>) ~ .ef-carousel__items .ef-carousel__item:nth-child(<?php echo $i ?>) {
     opacity: 1;
}
			 .ef-carousel__state:checked:nth-child(<?php echo $i ?>) ~ .ef-carousel__prev-group .ef-carousel__prev:nth-child(<?php echo $i ?>), .ef-carousel__state:checked:nth-child(<?php echo $i ?>) ~ .ef-carousel__next-group .ef-carousel__next:nth-child(<?php echo $i ?>) {
     display: block;
     opacity: 0;
}

 <?php } ?>
 <?php $i++; } ?>
 <?php } ?>

 .fill {
 	 width: 100%;
     object-fit: cover;
     justify-content: center;
     align-items: center;
     overflow: hidden;
     height: 95vh;
}
 .fill img {
     flex-shrink: 0;
     min-width: 100%;
     height: 100%;
}








/*MODAL*/

	/**
			 * modalews ($modalews)
			 */
			
			/* 1. Ensure this sits above everything when visible */
			.modalew {
			    position: absolute;
			    z-index: 10; /* 1 */
			    top: 0;
			    left: 0;
			    visibility: hidden;
			    width: 100%;
			    height: 100%;
			}
			
			.modalew.is-visible {
			    visibility: visible;
			}
			
			.modalew-overlay {
			  position: fixed;
			  z-index: 10;
			  top: 0;
			  left: 0;
			  width: 100%;
			  height: 100%;
			  background: hsla(0, 0%, 0%, 0.5);
			  visibility: hidden;
			  opacity: 0;
			  transition: visibility 0s linear 0.3s, opacity 0.3s;
			}
			
			.modalew.is-visible .modalew-overlay {
			  opacity: 1;
			  visibility: visible;
			  transition-delay: 0s;
			}
			
			.modalew-wrapper {
			  position: absolute;
			  z-index: 11;
			  /*top: 100vh;*/
			  width: 100vw;
			  height: 100vh;
			  background-color: #fff;
			  box-shadow: 0 0 1.5em hsla(0, 0%, 0%, 0.35);
			}
			
			.modalew-transition {
			  transition: all 0.3s 0.12s;
			  transform: translateY(-10%);
			  opacity: 0;
			}
			
			.modalew.is-visible .modalew-transition {
			  transform: translateY(0);
			  opacity: 1;
			}
			
			.modalew-header,
			.modalew-content {
			  padding: 1em;
			}
			
			.modalew-header {
			  position: relative;
			  background-color: #fff;
			  box-shadow: 0 1px 2px hsla(0, 0%, 0%, 0.06);
			  border-bottom: 1px solid #e8e8e8;
			}
			
			.modalew-close {
			  position: absolute;
			  top: 0;
			  right: 0;
			  padding: 1em;
			  color: #aaa;
			  background: none;
			  border: 0;
			}
			
			.modalew-close:hover {
			  color: #777;
			}
			
			.modalew-heading {
			  font-size: 1.125em;
			  margin: 0;
			  -webkit-font-smoothing: antialiased;
			  -moz-osx-font-smoothing: grayscale;
			}
			
			.modalew-content > *:first-child {
			  margin-top: 0;
			}
			
			.modalew-content > *:last-child {
			  margin-bottom: 0;
			}

/*=================MODALM FOR PREVIEW IMAGE===========*/

 /* Style the Image Used to Trigger the Modal */
.image-preview {
  border-radius: 5px;
  cursor: pointer;
  transition: 0.3s;
}

.image-preview:hover {opacity: 0.7;}

/* The Modal (background) */
.modal {
  display: none; /* Hidden by default */
  position: fixed; /* Stay in place */
  z-index: 1; /* Sit on top */
  padding-top: 100px; /* Location of the box */
  left: 0;
  top: 0;
  width: 100%; /* Full width */
  height: 100%; /* Full height */
  overflow: auto; /* Enable scroll if needed */
  background-color: rgb(0,0,0); /* Fallback color */
  background-color: rgba(0,0,0,0.9); /* Black w/ opacity */
}

/* Modal Content (Image) */
.modal-content {
  margin: auto;
  display: block;
  width: 80%;
  max-width: 700px;
}

/* Caption of Modal Image (Image Text) - Same Width as the Image */
#caption {
  margin: auto;
  display: block;
  width: 80%;
  max-width: 700px;
  text-align: center;
  color: #ccc;
  padding: 10px 0;
  height: 150px;
}

/* Add Animation - Zoom in the Modal */
.modal-content, #caption {
  animation-name: zoom;
  animation-duration: 0.6s;
}

@keyframes zoom {
  from {transform:scale(0)}
  to {transform:scale(1)}
}

/* The Close Button */
.close {
  position: absolute;
  top: 15px;
  right: 35px;
  color: #f1f1f1;
  font-size: 40px;
  font-weight: bold;
  transition: 0.3s;
}

.close:hover,
.close:focus {
  color: #bbb;
  text-decoration: none;
  cursor: pointer;
}

/* 100% Image Width on Smaller Screens */
@media only screen and (max-width: 700px){
  .modal-content {
    width: 100%;
  }
} 
/*=================MODALM FOR PREVIEW IMAGE===========*/

/*=================UPLOAD*/
#targetLayer {
	font-family: arial;
	margin-bottom: 20px;
}

.btn-upload {
	padding: 5px 30px;
	border-radius: 4px;
	margin-top: 20px;
	color: #2f2f2f;
	font-weight: 500;
	background-color: #ffc72c;
	border: 1px solid;
	border-color: #ffd98e #ffbe3d #de9300;
	cursor: pointer;
}
/*=================UPLOAD*/


/*=================NAVBAR==*/
 /* The navigation bar */
.navbar {
z-index:9;
  overflow: hidden;
  background-color: #263C5C;
  position: fixed; /* Set the navbar to fixed position */
  top: 0; /* Position the navbar at the top of the page */
  width: 100%; /* Full width */
}

/* Links inside the navbar */
.navbar a {
  float: left;
  display: block;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}

/* Change background on mouse-over */
.navbar a:hover {
  background: #ddd;
  color: black;
}

/* Main content */
.wrap {
  margin-top: 30px !important; /* Add a top margin to avoid content overlay */
} 

 .global-notice{
  margin-top: 60px !important; /* Add a top margin to avoid content overlay */
} 


.navbar svg {
	fill : #fff;
}
.navbar a {
	cursor:pointer ;
}
/*=================NAVBAR==*/


.custom-file-upload {
  border: 1px solid #ccc;
  display: inline-block;
  padding: 6px 12px;
  cursor: pointer;
}




/*==========SLIDER BUTTON======*/

 /* The switch - the box around the slider */
.switch {
  position: relative;
  display: inline-block;
  width: 50px;
  height: 24px;
}

/* Hide default HTML checkbox */
.switch input {
  opacity: 0;
  width: 0;
  height: 0;
}

/* The slider */
.slider {
  position: absolute;
  cursor: pointer;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-color: #ccc;
  -webkit-transition: .4s;
  transition: .4s;
}

.slider:before {
  position: absolute;
  content: "";
  height: 16px;
  width: 16px;
  left: 4px;
  bottom: 4px;
  background-color: white;
  -webkit-transition: .4s;
  transition: .4s;
}

input:checked + .slider {
  background-color: #2196F3;
}

input:focus + .slider {
  box-shadow: 0 0 1px #2196F3;
}

input:checked + .slider:before {
  -webkit-transform: translateX(26px);
  -ms-transform: translateX(26px);
  transform: translateX(26px);
}

/* Rounded sliders */
.slider.round {
  border-radius: 34px;
}

.slider.round:before {
  border-radius: 50%;
} 

/*==========SLIDER BUTTON======*/


/*========DELETE BUTTON====*/
.btndel, .modalew-close{
	fill : red;
	cursor: pointer;
}
/*========DELETE BUTTON====*/

.site-wrapper
{
width: 100vw;
margin-top: 20%;
}