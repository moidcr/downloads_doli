<?php

// Load Dolibarr environment
$res = 0;
// Try main.inc.php into web root known defined into CONTEXT_DOCUMENT_ROOT (not always defined)
if (!$res && !empty($_SERVER["CONTEXT_DOCUMENT_ROOT"])) $res = @include $_SERVER["CONTEXT_DOCUMENT_ROOT"]."/main.inc.php";
// Try main.inc.php into web root detected using web root calculated from SCRIPT_FILENAME
$tmp = empty($_SERVER['SCRIPT_FILENAME']) ? '' : $_SERVER['SCRIPT_FILENAME']; $tmp2 = realpath(__FILE__); $i = strlen($tmp) - 1; $j = strlen($tmp2) - 1;
while ($i > 0 && $j > 0 && isset($tmp[$i]) && isset($tmp2[$j]) && $tmp[$i] == $tmp2[$j]) { $i--; $j--; }
if (!$res && $i > 0 && file_exists(substr($tmp, 0, ($i + 1))."/main.inc.php")) $res = @include substr($tmp, 0, ($i + 1))."/main.inc.php";
if (!$res && $i > 0 && file_exists(dirname(substr($tmp, 0, ($i + 1)))."/main.inc.php")) $res = @include dirname(substr($tmp, 0, ($i + 1)))."/main.inc.php";
// Try main.inc.php using relative path
if (!$res && file_exists("../main.inc.php")) $res = @include "../main.inc.php";
if (!$res && file_exists("../../main.inc.php")) $res = @include "../../main.inc.php";
if (!$res && file_exists("../../../main.inc.php")) $res = @include "../../../main.inc.php";
if (!$res) die("Include of main fails");
$langs->load("customerdisplay@customerdisplay");

$images = array();
$idccs = 0;
$sql = 'SELECT * ';
$sql .= ' FROM customerdisplay_images as t where status = 1';
$resql = $db->query($sql);
if ($resql) {
	$num = $db->num_rows($resql);
	$i = 1;
	while ($i <= $num) {
		$obj = $db->fetch_object($resql);
		if ($obj) {
			$images[] = $obj;
			$idccs+=$obj->rowid;
		}
     	$i++; 
	}
} ?>
<!DOCTYPE html>
<!-- saved from url=(0039)https://spos.tecdiary.net/pos/view_bill -->
<html>
	<head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    
    <title>Customer Display | TakePOS</title>
    <!--<base href="https://spos.tecdiary.net/">--><base href=".">  
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="cache-control" content="max-age=0">
    <meta http-equiv="cache-control" content="no-cache">
    <meta http-equiv="expires" content="0">
    <meta http-equiv="pragma" content="no-cache">
    <link href="css/screen_style.css.php?id=<?php echo $idccs;?>" rel="stylesheet" type="text/css">
    <link rel="stylesheet" type="text/css" href="assets/DataTables/datatables.min.css"/>
 	
    </head>
<body class="with-promo-space">
<!-- just remove the class with-promo-space from body to make it full page -->
<noscript>
    <div class="global-notice noscript">
        <div class="notice-content">
            <h2><strong>JavaScript seems to be disabled in your browser.</strong><br>You must have JavaScript enabled in
                your browser to utilize the functionality of this website.</h2>
        </div>
    </div>
</noscript>
<div class="navbar">
  <a id="view-fullscreen"><svg  xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512" width="15px"><!-- Font Awesome Pro 5.15.4 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) --><path d="M448 344v112a23.94 23.94 0 0 1-24 24H312c-21.39 0-32.09-25.9-17-41l36.2-36.2L224 295.6 116.77 402.9 153 439c15.09 15.1 4.39 41-17 41H24a23.94 23.94 0 0 1-24-24V344c0-21.4 25.89-32.1 41-17l36.19 36.2L184.46 256 77.18 148.7 41 185c-15.1 15.1-41 4.4-41-17V56a23.94 23.94 0 0 1 24-24h112c21.39 0 32.09 25.9 17 41l-36.2 36.2L224 216.4l107.23-107.3L295 73c-15.09-15.1-4.39-41 17-41h112a23.94 23.94 0 0 1 24 24v112c0 21.4-25.89 32.1-41 17l-36.19-36.2L263.54 256l107.28 107.3L407 327.1c15.1-15.2 41-4.5 41 16.9z"/></svg></a>
  <a id = "modalew-e" class="modalew-toggle"><svg  xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" width="17px"><!-- Font Awesome Pro 5.15.4 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) --><path d="M464 448H48c-26.51 0-48-21.49-48-48V112c0-26.51 21.49-48 48-48h416c26.51 0 48 21.49 48 48v288c0 26.51-21.49 48-48 48zM112 120c-30.928 0-56 25.072-56 56s25.072 56 56 56 56-25.072 56-56-25.072-56-56-56zM64 384h384V272l-87.515-87.515c-4.686-4.686-12.284-4.686-16.971 0L208 320l-55.515-55.515c-4.686-4.686-12.284-4.686-16.971 0L64 336v48z"/></svg></a>
</div>


<div id ="wrap" class="wrap">
	
    <div class="bill" id="bill" style="height: 90vh;">
        <div id="product-list" style="height: 80vh;">
        	
            <table class="display nowrap dataTable dtr-inline collapsed" style="width:100%" id="billTable">
                <thead>
                <tr>
                    <th width="50%" class="text-center"><?php echo $langs->trans("Product_cust_disp"); ?></th>
                    <th width="15%" class="text-center"><?php echo $langs->trans("Disc_cust_disp"); ?></th>
                    <th width="15%" class="text-center"><?php echo $langs->trans("Quant_cust_disp"); ?></th>
                    <th width="20%" class="text-center"><?php echo $langs->trans("Total_cust_disp"); ?></th>
                </tr>
                </thead>
                <tbody>
                	
                </tbody>
            </table>
        </div>
        <div id="totals">
            <table  style="width:100%; float:right; padding:5px; color:#000; background: #FFF;" id="totalTable">
                <tbody>
                <tr>
                    <td style="border-left: 1px solid #ddd; padding-left:10px; text-align:left; font-weight:normal;">
                        <?php echo $langs->trans("Total_Items_P"); ?>                    </td>
                    <td style="text-align:right; padding-right:10px; font-weight:bold;"><span id="count">0</span></td>
                    <td style="padding-left:10px; text-align:left;"><?php echo $langs->trans("SubTotal_P"); ?> </td>
                    <td style="border-right: 1px solid #ddd; text-align:right; padding-right:10px; font-weight:bold;">
                        <span id="total">0.00</span></td>
                </tr>
                <tr>
                    <!--<td style="border-left: 1px solid #ddd; padding-left:10px; text-align:left; ">Discount</td>
                    <td style="text-align:right; padding-right:10px; font-weight:bold;">
                        <span id="ds_con">0.00</span></td>-->
                    <td style="border-left: 1px solid #ddd; padding-left:10px; text-align:left; "></td>
                    <td style="text-align:right; padding-right:10px; font-weight:bold;">
                        <span id="ds_con"></span></td>
                    <td style="padding-left:10px; text-align:left; font-weight:normal;"><?php echo $langs->trans("Order_Tax"); ?></td>
                    <td style="border-right: 1px solid #ddd; text-align:right; padding-right:10px; font-weight:bold;"><span id="ts_con">0.00</span></td>
                </tr>
                <tr>
                    <td colspan="2" style="padding: 5px 0px 5px 10px; text-align:left; font-size: 1.4em; border: 1px solid #333; font-weight:bold; background:#333; color:#FFF;">
                        <?php echo $langs->trans("Total_Payable"); ?>                    </td>
                    <td colspan="2" style="text-align:right; padding:5px 10px 5px 0px; font-size: 1.4em; border: 1px solid #333; font-weight:bold; background:#333; color:#FFF;">
                        <span id="total-payable">0.00</span></td>
                </tr>
                </tbody>
            </table>
            <div class="clearfix"></div>
        </div>
    </div>
    <?php if(count($images)>0)
	{?>
    <div class="main">
       <!-- <div class="content">
            <! -- you can display any promotional content by editing themes/yourtheme/views/promotions.php -- >
            <iframe class="preview_frame" src="./Customer Display _ SimplePOS_files/promotions.html" name="preview-frame" frameborder="0" noresize="noresize" style="height: 567px;"></iframe>
            <div class="clearfix"></div>
        </div>-->
        <div class="ef-carousel">
        	<!--  Each carousel on the page needs to have an unique name  -->
        	<?php
        		foreach($images as $i => $image) {?>
              				<input type="radio" name="unique-name" id="unique-name-<?php echo ($i+1) ?>" <?php echo (($i+1)==1 ? "checked" : "") ?> class="ef-carousel__state"/>
              	<?php } ?>
              <div class="ef-carousel__items fill">
              	<?php foreach($images as $image) {
              		 $link = DOL_URL_ROOT . $image->link;
              		?>
                	<img src="<?php echo  $link ; ?>" alt="" class="ef-carousel__item"/>
               <?php } ?>
              </div>
              <div class="ef-carousel__next-group">
              	<?php for($li = 2; $li <= count($images); $li++) {?>
                	<label for="unique-name-<?php echo $li ?>" class="ef-carousel__next"></label>
                <?php } ?>
				<?php if(count($images)>0) {?>
                <label for="unique-name-1" class="ef-carousel__next"></label>
                 <?php } ?>
              </div>
              
              
              <div class="ef-carousel__prev-group">
              	 <?php for($li = count($images); $li > 0; $li--) {?>
                	<label for="unique-name-<?php echo $li ?>" class="ef-carousel__prev"></label>
                <?php } ?>
              </div>
            </div>
    </div>
    <?php } else { ?>
    	<div align="center" class="site-wrapper" >
<div class="site-wrapper-inner">
<div class="cover-container">
<div class="masthead clearfix">
<div class="inner">
<h1 class="text-center"><?php echo $conf->global->MAIN_INFO_SOCIETE_NOM ?></h1>
</div>
<br />
</div>
<div class="inner cover">
<h3 class="cover-heading"><?php echo $langs->trans("thanks_you_msn"); ?></h3>
<p class="lead"><?php echo $langs->trans("come_back"); ?></p>

</div>
<div class="mastfoot">
<div class="inner">

</div>
</div>
</div>
</div>
</div>
    <?php } ?>
</div>

<div class="modalew">
	<div class="modalew-overlay modalew-toggle"></div>
		<div class="modalew-wrapper modalew-transition">
			<div class="modalew-header">
		    	<button class="modalew-close"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" width="30px"><!--! Font Awesome Pro 6.1.1 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) Copyright 2022 Fonticons, Inc. --><path d="M0 256C0 114.6 114.6 0 256 0C397.4 0 512 114.6 512 256C512 397.4 397.4 512 256 512C114.6 512 0 397.4 0 256zM175 208.1L222.1 255.1L175 303C165.7 312.4 165.7 327.6 175 336.1C184.4 346.3 199.6 346.3 208.1 336.1L255.1 289.9L303 336.1C312.4 346.3 327.6 346.3 336.1 336.1C346.3 327.6 346.3 312.4 336.1 303L289.9 255.1L336.1 208.1C346.3 199.6 346.3 184.4 336.1 175C327.6 165.7 312.4 165.7 303 175L255.1 222.1L208.1 175C199.6 165.7 184.4 165.7 175 175C165.7 184.4 165.7 199.6 175 208.1V208.1z"/></svg></button>
		        <h2 align="center" class="modalew-heading"><?php echo $langs->trans("Image_promos"); ?></h2>
		    </div>
		      
		    <div class="modalew-body">
			    <div class="modalew-content">
			    <frame>
					<html>
					<head>
					<title></title>
					<script src="https://code.jquery.com/jquery-3.6.0.min.js"
						crossorigin="anonymous"></script>
					</head>
					<body>
					
						<form id="image-upload-form" action="ajax/customerdisplay.php" method="post">
							<input type="hidden" name="token" value="<?php echo newToken()?>">
							<input type="hidden" name="action" value="UploadImg">
							<!--<div id="targetLayer">Image Preview</div>-->
							<div align="center">
								 <label for="userImage" class="custom-file-upload">
								    <i class="fa fa-cloud-upload"></i> <?php echo $langs->trans("Select_Image"); ?>
								 </label>
								<input id="userImage" name="userImage" type="file" class="inputFile" style="display:none;" />
								<input type="submit" value="<?php echo $langs->trans("Subir_Imagen"); ?>" class="btn-upload" />
							</div>
							
							<hr/>
							<br/>
							<table class="display nowrap dataTable dtr-inline collapsed" style="width:100%" id="TableImages">
					                <thead>
					                <tr>
					                    <th width="50%" class="text-center"><?php echo $langs->trans("Preview_image"); ?></th>
					                    <th width="25%" class="text-center"><?php echo $langs->trans("Date_image"); ?></th>
					                    <th width="25%" class="text-center"><?php echo $langs->trans("Options_image"); ?></th>
					                </tr>
					                </thead>
					                <tbody>
					                	<?php
					                	$sql = 'SELECT * ';
										$sql .= ' FROM customerdisplay_images as t';
							
										$resql = $db->query($sql);
										if ($resql) {
											$num = $db->num_rows($resql);
							
											$i = 0;
											while ($i < $num) {
												$obj = $db->fetch_object($resql);
												if ($obj) {
													$targetPath =  DOL_URL_ROOT.$obj->link;
													print '<tr>';
													print '<td align="center"><img class="image-preview" src="'.$targetPath.'" class="upload-preview" width="50" /></td>';
													print '<td>'.$obj->datec.'</td>';
													print '<td >';
													print '<table><tr><td><label title="'.$langs->trans("Options_st_image").'" class="switch">';
													print '  <input  id="checkimg'.$obj->rowid.'" onchange="StImg(\''.$obj->rowid.'\')" '.($obj->status ? 'checked' : '').' type="checkbox" >';
													print '  <span class="slider round"></span>';
													print '</label>';
													print ' </td> <td title="'.$langs->trans("Options_del_image").'"><svg onclick="DelImg(\''.$obj->rowid.'\')" class="btndel" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512" width="22px"><!--! Font Awesome Pro 6.1.1 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) Copyright 2022 Fonticons, Inc. --><path d="M135.2 17.69C140.6 6.848 151.7 0 163.8 0H284.2C296.3 0 307.4 6.848 312.8 17.69L320 32H416C433.7 32 448 46.33 448 64C448 81.67 433.7 96 416 96H32C14.33 96 0 81.67 0 64C0 46.33 14.33 32 32 32H128L135.2 17.69zM394.8 466.1C393.2 492.3 372.3 512 346.9 512H101.1C75.75 512 54.77 492.3 53.19 466.1L31.1 128H416L394.8 466.1z"/></svg></td></tr></table>';
													print '</td>';
													print '</tr>';
												}
												$i++;
											}
										}
										?>
					                </tbody>
					            </table>
								
						</form>
						<script type="text/javascript">
					    $(document).ready(function (e) {
					    	$("#image-upload-form").on('submit',(function(e) {
					    		e.preventDefault();
					    		$.ajax({
					            	url: "ajax/customerdisplay.php",
					    			type: "POST",
					    			data:  new FormData(this),
					    			contentType: false,
					        	    cache: false,
					    			processData: false,
					    			success: function(data)
					    		    {
					    		    	var obj = JSON.parse(data);
					    		    	if(obj.Res=="OK")
					    		    	{
					    		    		localStorage.setItem("UpImg",1);
					    		    		alert("<?php echo $langs->trans("Image_success"); ?>");
					    		    		location.reload();
					    		    	}
					    		    	else if(obj.Res=="Exist")
					    		    	{
					    		    		alert("<?php echo $langs->trans("Image_exist"); ?>");
					    		    	}
					    		    	else
					    		    	{
					    		    		alert("<?php echo $langs->trans("Image_error"); ?>");
					    		    	}
					    				//$("#targetLayer").html(data);
					    		    },
					    		  	error: function(data)
					    	    	{
					    		  	  console.log("error");
					                  console.log(data);
					    	    	}
					    	   });
					    	}));
					    	
					    	
					    	
					    });
					    
					    function StImg(imgid)
					    {
					    	var ck = 0;
					    	if ($('#checkimg'+imgid).is(':checked')) {
					    		ck = 1;
					    	}
					    	$.ajax({
					            	url: "ajax/customerdisplay.php",
					    			type: "POST",
					    			data:  {token: '<?php echo currentToken(); ?>', action: "StImg", imgid: imgid, ck: ck},
					    			success: function(data)
					    		    {
					    		    	var obj = JSON.parse(data);
					    		    	if(obj.Res=="OK")
					    		    	{
					    		    		
					    		    	}
					    		    	else
					    		    	{
					    		    		alert("<?php echo $langs->trans("Image_st_err"); ?>");
					    		    	}

					    				//$("#targetLayer").html(data);
					    		    },
					    		  	error: function(data)
					    	    	{
					    		  	  console.log("error");
					                  console.log(data);
					    	    	}
					    	   });
					    }
					    function DelImg(imgid)
					    {
					    	if(confirm("<?php echo $langs->trans("Image_del_confirm"); ?>"))
					    	{
						    	$.ajax({
						            	url: "ajax/customerdisplay.php",
						    			type: "POST",
						    			data:  {token: '<?php echo currentToken(); ?>', action: "DelImg", imgid: imgid},
						    			success: function(data)
						    		    {
						    		    	var obj = JSON.parse(data);
						    		    	if(obj.Res=="OK")
						    		    	{
						    		    		localStorage.setItem("UpImg",1);
						    		    		alert("<?php echo $langs->trans("Image_del_success"); ?>");
						    		    		location.reload();
						    		    	}
						    		    	else
						    		    	{
						    		    		alert("<?php echo $langs->trans("Image_del_err"); ?>");
						    		    	}
	
						    				//$("#targetLayer").html(data);
						    		    },
						    		  	error: function(data)
						    	    	{
						    		  	  console.log("error");
						                  console.log(data);
						    	    	}
						    	   });
					    	  }
					    }
					</script>
					
					
					 <!-- Trigger the Modal -->
						
						<!-- The Modal -->
						<div id="myModal" class="modal">
						
						  <!-- The Close Button -->
						  <span class="close">&times;</span>
						
						  <!-- Modal Content (The Image) -->
						  <img class="modal-content" id="img01">
						
						  <!-- Modal Caption (Image Text) -->
						  <div id="caption">
						  	
						  </div>
						</div> 

					</body>
					</html>

				</frame>
			</div>
		</div>
	</div>
</div>



<script src="js/jQuery-2.1.4.min.js"></script>
<script type="text/javascript" src="assets/DataTables/datatables.min.js"></script>
<script type="text/javascript">

var viewFullScreen = document.getElementById("view-fullscreen");
if (viewFullScreen) {
  viewFullScreen.addEventListener("click", function() {
    var docElm = document.getElementById("wrap");
    if (docElm.requestFullscreen) {
      docElm.requestFullscreen();
    } else if (docElm.msRequestFullscreen) {
      docElm.msRequestFullscreen();
    } else if (docElm.mozRequestFullScreen) {
      docElm.mozRequestFullScreen();
    } else if (docElm.webkitRequestFullScreen) {
      docElm.webkitRequestFullScreen();
    }
  })
}
var tabledata, tableimages ;
function initTableScreen()
{
	tabledata = $('#billTable').DataTable( {
		"language": {
            "zeroRecords": "<?php echo $langs->trans("zeroRecords"); ?>",
       },
	    "bPaginate": false,
	    "bInfo": false,
	    searching: false,
	    "order": [],
 		ordering:  false,
 		scrollY: '80vh',
        scrollCollapse: true,
	});
}

var ItemsFirstC = [];
//localStorage.setItem("ChangedBill",-1);
function LoadCustDisp()
{
	var placeid = localStorage.getItem('placeid');

	var Items = JSON.parse(localStorage.getItem('Items'));
	$('#billTable').DataTable().destroy();
	$("#billTable tbody").html("");
	
	var cpr = 0;
	for(var tr of Items)
	{
		$("#billTable").find('tbody').append("<tr>"+tr+"</tr>");
		cpr++;
	}
	//tabledata.data().refresh(); 
	initTableScreen();
	var scrollBody = $($('#billTable').get(0)).parent()
	scrollBody.scrollTop(scrollBody.get(0).scrollHeight);
	
	$("#count").html(cpr);
	$("#total-payable").html(localStorage.getItem('SaleTotal'));
	
	
	if(placeid!=-1)
		CheckTotals(placeid);
}

function CheckTotals(facid)
{
	$.ajax({
		type: "POST",
		url: "ajax/customerdisplay.php",
		data: { token: '<?php echo currentToken(); ?>', action: "CheckTotals", facid: facid},
		success: function(data, status, xhr) {
			var obj = JSON.parse(data); //if the dataType is not specified as json uncomment this
			if(obj.Res == "Ok")
			{
				$("#count").html(obj.fact.Lines);
				$("#total").html(obj.fact.SubTotal);
				$("#ts_con").html(obj.fact.Tax);
				$("#total-payable").html(obj.fact.Total);
			}
			else
			{
				$("#count").html("0");
				$("#total").html("0.00");
				$("#ts_con").html("0.00");
				$("#total-payable").html("0.00");
			}
		    
		       
		},
		error: function() {
			//alert('error handling here');
		}
		});
}

var FirstLoad = 1;
$(document).ready( function () {
    initTableScreen();
    
    
    
    setInterval(function () {
    if(localStorage.getItem("ChangedBill") == "1" || FirstLoad == 1)
    {
    	console.log("Read");
    	FirstLoad = 0;
    	localStorage.setItem("ChangedBill","0");
    	LoadCustDisp();
    }
    	
    }, 500);
    
    
    
    
    $(".modalew-toggle").on("click", function(e) {
		e.preventDefault();
		$(".modalew").toggleClass("is-visible");
		lockScroll(); 
	});
	
	$(".modalew-close").on("click", function(e) {
		e.preventDefault();
		$(".modalew").toggleClass("is-visible");
		unlockScroll();
		location.reload();
	});
    
    $('#userImage').change(function() {
	  var i = $(this).prev('label').clone();
	  var file = $('#userImage')[0].files[0].name;
	  $(this).prev('label').text(file);
	});
	
	tableimages = $('#TableImages').DataTable( {
		"language": {
            "zeroRecords": "<?php echo $langs->trans("Load_images_here"); ?>",
       },
	    "bPaginate": false,
	    "bInfo": false,
	    "columns":[
            {
                "sortable": false
            },
            {
                "sortable": true
            },
            {
                "sortable": false
            },
            
        ],
	    searching: false,
 		scrollY: '80vh',
        scrollCollapse: true,
	});
    
    $(".image-preview").on("click", function(e) {
		 modal_image(this);
	});
	
	var upi = localStorage.getItem('UpImg');
    if(upi=="1")
    {
    	localStorage.setItem("UpImg",0);
		$("#modalew-e").click();

    }
    
     setInterval(function () {
    	$(".ef-carousel__next:visible").click();
    	console.log($(".ef-carousel__next:visible"));
    }, 5000);
    
    $("#userImage").change(function () {
        var fileExtension = ['jpeg', 'jpg', 'png', 'gif', 'bmp'];
        if ($.inArray($(this).val().split('.').pop().toLowerCase(), fileExtension) == -1) {
        	$("#userImage").val("");
            alert("<?php echo $langs->trans("images_extension_only"); ?> : "+fileExtension.join(', '));
        }
    });
   
    
} );

function lockScroll(){
    $html = $('html'); 
    $body = $('body'); 
    var initWidth = $body.outerWidth();
    var initHeight = $body.outerHeight();

    var scrollPosition = [
        self.pageXOffset || document.documentElement.scrollLeft || document.body.scrollLeft,
        self.pageYOffset || document.documentElement.scrollTop  || document.body.scrollTop
    ];
    $html.data('scroll-position', scrollPosition);
    $html.data('previous-overflow', $html.css('overflow'));
    $html.css('overflow', 'hidden');
    window.scrollTo(scrollPosition[0], scrollPosition[1]);   

    var marginR = $body.outerWidth()-initWidth;
    var marginB = $body.outerHeight()-initHeight; 
    $body.css({'margin-right': marginR,'margin-bottom': marginB});
} 

function unlockScroll(){
    $html = $('html');
    $body = $('body');
    $html.css('overflow', $html.data('previous-overflow'));
    var scrollPosition = $html.data('scroll-position');
    window.scrollTo(scrollPosition[0], scrollPosition[1]);    

    $body.css({'margin-right': 0, 'margin-bottom': 0});
}

function modal_image(image)
{
	// Get the modal
	var modal = document.getElementById("myModal");
	
	// Get the image and insert it inside the modal - use its "alt" text as a caption
	var img = image;
	var modalImg = document.getElementById("img01");
	var captionText = document.getElementById("caption");
	modal.style.display = "block";
	modalImg.src = img.src;
	  //captionText.innerHTML = this.alt;
	
	// Get the <span> element that closes the modal
	var span = document.getElementsByClassName("close")[0];
	
	// When the user clicks on <span> (x), close the modal
	span.onclick = function() {
	  modal.style.display = "none";
	} 
}
</script>

</body></html>