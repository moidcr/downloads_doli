<?php
/* Copyright (C) 2001-2005 Rodolphe Quiedeville <rodolphe@quiedeville.org>
 * Copyright (C) 2004-2015 Laurent Destailleur  <eldy@users.sourceforge.net>
 * Copyright (C) 2005-2012 Regis Houssin        <regis.houssin@inodbox.com>
 * Copyright (C) 2015      Jean-François Ferry	<jfefe@aternatik.fr>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */

/**
 *	\file       monitorcomandas/monitorcomandasindex.php
 *	\ingroup    monitorcomandas
 *	\brief      Home page of monitorcomandas top menu
 */

// Load Dolibarr environment
// Load Dolibarr environment
$res = 0;
// Try main.inc.php into web root known defined into CONTEXT_DOCUMENT_ROOT (not always defined)
if (!$res && !empty($_SERVER["CONTEXT_DOCUMENT_ROOT"])) $res = @include $_SERVER["CONTEXT_DOCUMENT_ROOT"]."/main.inc.php";
// Try main.inc.php into web root detected using web root calculated from SCRIPT_FILENAME
$tmp = empty($_SERVER['SCRIPT_FILENAME']) ? '' : $_SERVER['SCRIPT_FILENAME']; $tmp2 = realpath(__FILE__); $i = strlen($tmp) - 1; $j = strlen($tmp2) - 1;
while ($i > 0 && $j > 0 && isset($tmp[$i]) && isset($tmp2[$j]) && $tmp[$i] == $tmp2[$j]) { $i--; $j--; }
if (!$res && $i > 0 && file_exists(substr($tmp, 0, ($i + 1))."/main.inc.php")) $res = @include substr($tmp, 0, ($i + 1))."/main.inc.php";
if (!$res && $i > 0 && file_exists(dirname(substr($tmp, 0, ($i + 1)))."/main.inc.php")) $res = @include dirname(substr($tmp, 0, ($i + 1)))."/main.inc.php";
// Try main.inc.php using relative path
if (!$res && file_exists("../main.inc.php")) $res = @include "../main.inc.php";
if (!$res && file_exists("../../main.inc.php")) $res = @include "../../main.inc.php";
if (!$res && file_exists("../../../main.inc.php")) $res = @include "../../../main.inc.php";
if (!$res) die("Include of main fails");

require_once DOL_DOCUMENT_ROOT.'/core/class/html.formfile.class.php';
require_once DOL_DOCUMENT_ROOT.'/core/class/canvas.class.php';
require_once DOL_DOCUMENT_ROOT.'/core/class/html.formcompany.class.php';
require_once DOL_DOCUMENT_ROOT.'/core/class/genericobject.class.php';
require_once DOL_DOCUMENT_ROOT.'/core/lib/company.lib.php';
require_once DOL_DOCUMENT_ROOT.'/categories/class/categorie.class.php';

// Load translation files required by the page
$langs->load("monitorcomandas@monitorcomandas");

$mesg = ''; $error = 0; $errors = array();

$refalreadyexists = 0;

$id = GETPOST('id', 'int');
$action = (GETPOST('action', 'alpha') ? GETPOST('action', 'alpha') : 'view');
$cancel = GETPOST('cancel', 'alpha');
$backtopage = GETPOST('backtopage', 'alpha');
$confirm = GETPOST('confirm', 'alpha');
$socid = GETPOST('socid', 'int');
$lineid   = GETPOST('lineid', 'int');


// by default 'alphanohtml' (better security); hidden conf MAIN_SECURITY_ALLOW_UNSECURED_LABELS_WITH_HTML allows basic html
$label_security_check = empty($conf->global->MAIN_SECURITY_ALLOW_UNSECURED_LABELS_WITH_HTML) ? 'alphanohtml' : 'restricthtml';

if (!empty($user->socid)) {
	$socid = $user->socid;
}

$object = new GenericObject($db);



	// Actions cancel, add, update, delete or clone quality object
	include 'core/class/actions_monitorcomandas.class.php';
	if ($action == 'confirm_deleteline')
	{
		header("location:".$_SERVER["PHP_SELF"]);
	}

$max = 5;
$now = dol_now();


/*
 * Actions
 */

// None

// Security check
$result = restrictedArea($user, 'monitorcomandas', 0, '', 'myobject');

/*
 * View
 */
 
 // Initialize technical object to manage hooks. Note that conf->hooks_modules contains array
$hookmanager->initHooks(array('monitorcomandas'));

$parameters = array('user' => $user);
$reshook = $hookmanager->executeHooks('CustomActions', $parameters); // Note that $action and $object may have been modified by hook

 

$form = new Form($db);
$formfile = new FormFile($db);

llxHeader("", $langs->trans("MonitorComandas"));

print load_fiche_titre($langs->trans("MonitorComandasArea"), '', 'monitormomandas.png@monitormomandas');

// Part to show record
if ((empty($action) || ($action != 'edit')))
{

	$formconfirm = '';

	// Confirmation to delete
	if ($action == 'delete')
	{
		$formconfirm = $form->formconfirm($_SERVER["PHP_SELF"].'?id='.$object->id, $langs->trans('DeleteMuPrOf'), $langs->trans('ConfirmDelete'), 'confirm_delete', '', 0, 1);
	}
	// Confirmation to delete line
	if ($action == 'deleteline')
	{
		$formconfirm = $form->formconfirm($_SERVER["PHP_SELF"].'?lineid='.$lineid, $langs->trans('DeleteLine'), $langs->trans('ConfirmDeleteLine'), 'confirm_deleteline', '', 0, 1);
	}


	// Call Hook formConfirm
	$parameters = array('formConfirm' => $formconfirm, 'lineid' => $lineid);
	$reshook = $hookmanager->executeHooks('formConfirm', $parameters, $object, $action); // Note that $action and $object may have been modified by hook
	if (empty($reshook)) $formconfirm .= $hookmanager->resPrint;
	elseif ($reshook > 0) $formconfirm = $hookmanager->resPrint;

	// Print form confirm
	print $formconfirm;


	// Object card
	// ------------------------------------------------------------
	$linkback = '<a href="'.dol_buildpath('/multiprodof/muprof_list.php', 1).'?restore_lastsearch_values=1'.(!empty($socid) ? '&socid='.$socid : '').'">'.$langs->trans("BackToList").'</a>';

	print '<div class="fichecenter">';
	print '<div class="fichehalfleft">';
	print '<div class="underbanner clearboth"></div>';
	print '<table class="border centpercent tableforfield">'."\n";


	print '</table>';
	print '</div>';
	print '</div>';

	print '<div class="clearboth"></div>';

	print '<div id="qualitysheet" style=" width:80vw; overflow-x:auto !important;">';
		print '<style>table.liste th, table.noborder th, table.noborder tr.liste_titre td, table.noborder tr.box_titre td, table.liste td, table.noborder td, div.noborder form div, table.tableforservicepart1 td, table.tableforservicepart2 td {
	padding: 7px 2px 7px 2px !important;
} table.noborder{font-size: 0.80em;}</style>';
		print '	<form  name="addrule" id="addrule" action="'.$_SERVER["PHP_SELF"].(($action != 'editline') ? '#addline' : '').'" method="POST">
		<input type="hidden" name="token" value="' . newToken().'">
		<input type="hidden" name="action" value="' . (($action != 'editline') ? 'addlinerule' : 'updatelinerule').'">
		<input type="hidden" name="mode" value="">
		<input type="hidden" name="backtopage" value="'.$backtopage.'">';
		
		if (!empty($conf->use_javascript_ajax) ) {
			//include DOL_DOCUMENT_ROOT.'/core/tpl/ajaxrow.tpl.php';
		}

			print '<table  id="tablelines" class="noborder noshadow" >';
	
	 

			// Form to add new line

				if ($action != 'editline')
				{
					include('tpl/objectline_title.tpl.php');

					include('tpl/objectline_create.tpl.php');

	
				}

			$sql = 'SELECT * ';
			$sql .= ' FROM '.MAIN_DB_PREFIX.'monitor_comandas as t';

			$resql = $db->query($sql);
			if ($resql) {
				$num = $db->num_rows($resql);

				$i = 0;
				include('tpl/objectline_title.tpl.php');
				while ($i < $num) {
					$obj = $db->fetch_object($resql);
					
					//($obj);
					if ($obj) {
						$coldisplay = 0;
						if($action == 'editline' && $obj->rowid == $lineid )
						{

							include('tpl/objectline_edit.tpl.php');
						}
						else {
							
							include('tpl/objectline_view.tpl.php');
						}
					}
					$i++;
				}
			}



			print '</table>';

		print '</div>';


		print "</form>\n";
		print "</div>";


}

?>
<style>
	.imcheck, .imcan{cursor:pointer}
</style>

<?php

// End of page
llxFooter();
//echo "<pre>";
//print_r($extrafields);
$labes_ex = $extrafields->attribute_label;
$edits_ex = $extrafields->attribute_alwayseditable;

?>

<div style="display:none">

	<?php print $object->showOptionals($extrafields, 'create', '');?>
</div>
<script>

$(document).ready(function() {
	"use strict";
	//Init event


	$('#fields').select2({
		dir: 'ltr',

	});


	$("#addline").on('click', function(){
		CheckLine();
	});

	$("#savelinebutton").on('click', function(){
		CheckLine();
	});


	//==========> view lines <===========
		var Trs = document.querySelectorAll(".listrules");

		$(".listrules").show();
	//==========> view lines <===========



	$('#fields + .select2').addClass(' widthcentpercentminusx');

	$("#create_td > select ").attr("onchange","select_camp()");
	//==========> edit line <============

});



CheckLine = function()
{
	var fail=0;

	var campo = "";
	var campe = "";
	var campi = "";

	if($("#titulo").length >0 )
	{
		campo = $("#titulo").val();
	}

	if($("#categories").length >0 )
		campe = $("#categories").val();
//alert("||"+campo+"||");


	if(campo == "" || campe.length == 0 )
	{
		alert("<?php echo $langs->trans("llene_todos")?>");
	}
	else
	{
		//alert("exito");
		if($("#addline").length > 0)
		{
			$("#addline").attr("type",'submit');
			$("#addline").attr("id",'addline2');
			$("#addline").click();
		}
		if($("#savelinebutton").length > 0)
		{
			$("#savelinebutton").attr("type",'submit');
			$("#savelinebutton").attr("id",'savelinebutton2');
			$("#savelinebutton").click();
		}

	}
}
</script>
<?php

function containingh($obj, $id, $type, $mode = 'object')
	{

		global $db;
		
		$cats = array();


			$sql = "SELECT ct.fk_categorie, c.label, c.rowid";
			$sql .= " FROM ".MAIN_DB_PREFIX."monitor_comandas_categorie as ct, ".MAIN_DB_PREFIX."categorie as c";
			$sql .= " WHERE ct.fk_categorie = c.rowid AND ct.fk_monitor = ".(int) $id;
			// This  containing() useless because the table already contains id of category of 1 unique type. So commented.
			// So now it works also with external added categories.
			//$sql .= " AND c.type = ".((int) $this->MAP_ID[$type]);
			$sql .= " AND c.entity IN (".getEntity('category').")";

			$res = $db->query($sql);
			if ($res) {
				//return "mk";
				while ($objg = $db->fetch_object($res)) {
					 
					if ($mode == 'id') {
						$cats[] = $objg->rowid;
					} elseif ($mode == 'label') {
						$cats[] = $objg->label;
					} else {
						$cat = new Categorie($db);
						$cat->fetch($objg->fk_categorie);
						$cats[] = $cat;
					}
				}
			} else {
				dol_print_error($obj->db);
				return "dddd";
			}
		

		return $cats;
	}


	function showCategoriesv($obj, $id, $type, $rendermode = 0, $nolink = 0)
	{
		
		global $db;
 
		include_once DOL_DOCUMENT_ROOT.'/categories/class/categorie.class.php';

		$cat = new Categorie($db);
		$categories = containingh($obj,$id, $type);
		//return $categories;
		
		if ($rendermode == 1) {
			$toprint = array();
			foreach ($categories as $c) {
				$ways = $c->print_all_ways(' &gt;&gt; ', ($nolink ? 'none' : ''), 0, 1); // $ways[0] = "ccc2 >> ccc2a >> ccc2a1" with html formated text
				foreach ($ways as $way) {
					$toprint[] = '<li class="select2-search-choice-dolibarr noborderoncategories"'.($c->color ? ' style="background: #'.$c->color.';"' : ' style="background: #bbb"').'>'.$way.'</li>';
				}
			}
			return '<div class="select2-container-multi-dolibarr" style="width: 90%;"><ul class="select2-choices-dolibarr">'.implode(' ', $toprint).'</ul></div>';
		}
		
		return 'ErrorBadValueForParameterRenderMode'; // Should not happene
	}
	 
$db->close();
