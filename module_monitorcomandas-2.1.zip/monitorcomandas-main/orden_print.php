<?php
/* Copyright (C) 2007-2008 Jeremie Ollivier    <jeremie.o@laposte.net>
 * Copyright (C) 2011      Laurent Destailleur <eldy@users.sourceforge.net>
 * Copyright (C) 2012      Marcos García       <marcosgdf@gmail.com>
 * Copyright (C) 2018      Andreu Bisquerra    <jove@bisquerra.com>
 * Copyright (C) 2019      Josep Lluís Amador  <joseplluis@lliuretic.cat>
 * Copyright (C) 2021    Nicolas ZABOURI    <info@inovea-conseil.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */

/**
 *	\file       htdocs/takepos/receipt.php
 *	\ingroup    takepos
 *	\brief      Page to show a receipt.
 */
 
 // Load Dolibarr environment
$res = 0;
// Try main.inc.php into web root known defined into CONTEXT_DOCUMENT_ROOT (not always defined)
if (!$res && !empty($_SERVER["CONTEXT_DOCUMENT_ROOT"])) $res = @include $_SERVER["CONTEXT_DOCUMENT_ROOT"]."/main.inc.php";
// Try main.inc.php into web root detected using web root calculated from SCRIPT_FILENAME
$tmp = empty($_SERVER['SCRIPT_FILENAME']) ? '' : $_SERVER['SCRIPT_FILENAME']; $tmp2 = realpath(__FILE__); $i = strlen($tmp) - 1; $j = strlen($tmp2) - 1;
while ($i > 0 && $j > 0 && isset($tmp[$i]) && isset($tmp2[$j]) && $tmp[$i] == $tmp2[$j]) { $i--; $j--; }
if (!$res && $i > 0 && file_exists(substr($tmp, 0, ($i + 1))."/main.inc.php")) $res = @include substr($tmp, 0, ($i + 1))."/main.inc.php";
if (!$res && $i > 0 && file_exists(dirname(substr($tmp, 0, ($i + 1)))."/main.inc.php")) $res = @include dirname(substr($tmp, 0, ($i + 1)))."/main.inc.php";
// Try main.inc.php using relative path
if (!$res && file_exists("../main.inc.php")) $res = @include "../main.inc.php";
if (!$res && file_exists("../../main.inc.php")) $res = @include "../../main.inc.php";
if (!$res && file_exists("../../../main.inc.php")) $res = @include "../../../main.inc.php";
if (!$res) die("Include of main fails");

if (!isset($action)) {
	//if (! defined('NOREQUIREUSER'))	define('NOREQUIREUSER', '1');	// Not disabled cause need to load personalized language
	//if (! defined('NOREQUIREDB'))		define('NOREQUIREDB', '1');		// Not disabled cause need to load personalized language
	//if (! defined('NOREQUIRESOC'))		define('NOREQUIRESOC', '1');
	//if (! defined('NOREQUIRETRAN'))		define('NOREQUIRETRAN', '1');
	if (!defined('NOTOKENRENEWAL')) {
		define('NOTOKENRENEWAL', '1');
	}
	if (!defined('NOREQUIREMENU')) {
		define('NOREQUIREMENU', '1');
	}
	if (!defined('NOREQUIREHTML')) {
		define('NOREQUIREHTML', '1');
	}
	if (!defined('NOREQUIREAJAX')) {
		define('NOREQUIREAJAX', '1');
	}
}
include_once DOL_DOCUMENT_ROOT.'/compta/facture/class/facture.class.php';

$langs->loadLangs(array("main", "cashdesk", "companies"));

$place = (GETPOST('place', 'aZ09') ? GETPOST('place', 'aZ09') : 0); // $place is id of table for Bar or Restaurant

$facid = GETPOST('facid', 'int');

$monitor = GETPOST('monitor', 'int');

$orderid = GETPOST('orderid', 'int');

if (empty($user->rights->takepos->run)) {
	accessforbidden();
}


/*
 * View
 */

top_httphead('text/html');

if ($place > 0) {
	$sql = "SELECT rowid FROM ".MAIN_DB_PREFIX."facture where ref='(PROV-POS".$_SESSION["takeposterminal"]."-".$place.")'";
	$resql = $db->query($sql);
	$obj = $db->fetch_object($resql);
	if ($obj) {
		$facid = $obj->rowid;
	}
}
$object = new Facture($db);
$object->fetch($facid);

// Call to external receipt modules if exist
$hookmanager->initHooks(array('takeposfrontend'), $facid);
$reshook = $hookmanager->executeHooks('TakeposReceipt', $parameters, $object);
if (!empty($hookmanager->resPrint)) {
	print $hookmanager->resPrint;
	exit;
}

// IMPORTANT: This file is sended to 'Takepos Printing' application. Keep basic file. No external files as css, js... If you need images use absolute path.
?>
<html>
<body>
<style>
.right {
	text-align: right;
}
.center {
	text-align: center;
}
.left {
	text-align: left;
}
</style>
<br>
<!--
<p style="display:none" class="left">
<?php
$constFreeText = 'TAKEPOS_HEADER'.$_SESSION['takeposterminal'];
if (!empty($conf->global->TAKEPOS_HEADER) || !empty($conf->global->{$constFreeText})) {
	$newfreetext = '';
	$substitutionarray = getCommonSubstitutionArray($langs);
	if (!empty($conf->global->TAKEPOS_HEADER)) {
		$newfreetext .= make_substitutions($conf->global->TAKEPOS_HEADER, $substitutionarray);
	}
	if (!empty($conf->global->{$constFreeText})) {
		$newfreetext .= make_substitutions($conf->global->{$constFreeText}, $substitutionarray);
	}
	print nl2br($newfreetext);
}
?>
</p>-->
<center>
<?php print '<h3>Orden '.$orderid.'</h3>';?>
</center>
<p  class="right">
<?php
$plan = explode("-", $object->ref);
$Lug = explode(")",$plan[2]);


print $langs->trans('Date')." ".dol_print_date($object->date, 'day').'<br>';
if (!empty($conf->global->TAKEPOS_RECEIPT_NAME)) {
	print $conf->global->TAKEPOS_RECEIPT_NAME." ";
}
if ($object->statut == Facture::STATUS_DRAFT) {
	print str_replace(")", "", str_replace("-", " ".$langs->trans('Place')." ", str_replace("(PROV-POS", $langs->trans("Terminal")." ", $object->ref)));
} else {
	print $object->ref;
}
if ($conf->global->TAKEPOS_SHOW_CUSTOMER) {
	if ($object->socid != $conf->global->{'CASHDESK_ID_THIRDPARTY'.$_SESSION["takeposterminal"]}) {
		$soc = new Societe($db);
		if ($object->socid > 0) {
			$soc->fetch($object->socid);
		} else {
			$soc->fetch($conf->global->{'CASHDESK_ID_THIRDPARTY'.$_SESSION["takeposterminal"]});
		}
		print "<br>".$langs->trans("Customer").': '.$soc->name;
	}
}
?>
</p>
<br>
<form action="POST" id="OrderForm"  name="OrderForm" >
<input id="action" name="action" type="hidden" value="SendOrder" />
<input id="Lugar" name="Lugar" type="hidden" value="<?php echo $Lug[0]; ?>" />
<input id="facid" name="facid" type="hidden" value="<?php echo $facid; ?>" />
<table width="100%" style="border-top-style: double;">
	<thead>
	<tr>
		<th class="left">#</th>
		<th class="left"><?php print $langs->trans("Label"); ?></th>
		<th class="left"><?php print $langs->trans("Qty"); ?></th>
		<th class="left"><?php print $langs->trans("Tipo"); ?></th>
		<!--<th hidden class="right"><?php if ($gift != 1) {
			print $langs->trans("Price");
					} ?></th>-->
		<?php  if (!empty($conf->global->TAKEPOS_SHOW_HT_RECEIPT)) { ?>
		<!--<th class="right"><?php if ($gift != 1) {
			print $langs->trans("TotalHT");
				} ?></th>-->
		<?php } ?>
		<!--<th hidden class="right"><?php if ($gift != 1) {
			print $langs->trans("TotalTTC");
					} ?></th>-->
	</tr>
	</thead>
	<tbody>
	<?php
	$categorys = array();
	
	$smc = "SELECT fk_categorie from ".MAIN_DB_PREFIX."monitor_comandas_categorie where fk_monitor = '".$monitor."' ";
			
	$resmc = $db->query($smc);
	if ($resmc)
	{
		$nuc = $db->num_rows($resmc);
		$c = 0;
		while ($c < $nuc)
		{
			$obm = $db->fetch_object($resmc);
			if ($obm)
			{
				$categorys[]= $obm->fk_categorie;	
			}
			$c++;
		}
	}
	$lins = 0;
	$platesab = array();
	$platesab[0] = "-";
	$platesab[1] = "EN";
	$platesab[2] = "PP";
	$platesab[3] = "SP";
	$platesab[4] = "PO";
	$sqd = " select mc.rowid as line_id, pr.label as pr_label, mc.qty, ifnull(mc.qty_check,0) as qty_check, ifnull(mc.type,0) as type, (select group_concat(fk_categorie) from ".MAIN_DB_PREFIX."categorie_product where fk_product = pr.rowid) as categories,  ifnull((select monitor from ".MAIN_DB_PREFIX."product_extrafields where fk_object = pr.rowid),'') as monitor";
	$sqd .= " FROM ".MAIN_DB_PREFIX."monitor_comandas_orders_details mc join ".MAIN_DB_PREFIX."product pr on mc.fk_product = pr.rowid where mc.fk_order = '".$orderid."' order by mc.type, pr_label";
					//echo $sqd."<br><br><br>";
				$resqd = $db->query($sqd);
				if ($resqd)
				{
					//echo "hooo";
					$nud = $db->num_rows($resqd);
					$j = 0;
					while ($j < $nud)
					{
						
						$obd = $db->fetch_object($resqd);
						if ($obd)
						{
							
							//Validacion por categorias
							$categs = explode(",", $obd->categories);
							//print_r($categs);
							$pass = false;
							if($obd->monitor !="" && $obd->monitor != 0 && $obd->monitor == $monitor)
							{
								$pass = true;
							}
							if(!$pass)
							{
								foreach($categs as $cat)
								{
									if(in_array($cat, $categorys))
									{
										$pass = true;
									}
								}
							}
							//Validacion por categorias
							
							if($pass)
							{
								?>
								<tr>
								<td class="left">
								</td>
								<td class="left">
									<?php echo $obd->pr_label; ?>
	
								</td>
								<td class="left">
									<?php echo $obd->qty; ?>
	
								</td>
		
								<td class="left">
									
									<?php echo $platesab[$obd->type]; ?>
		
								</td>
								</tr>
							<?php }
						}
						$j++;
					}
				}
	?>
	</tbody>
</table>
<input type="hidden" id="raws" value="<?php echo $lins; ?>"/>
</form>


<div style="border-top-style: double;">
	<!--<p class="center">
		<?php echo $langs->trans('Place');?>: 
	
	<select id="nlugar">
	<?php
	$sfl = "SELECT floor FROM ".MAIN_DB_PREFIX."takepos_floor_tables group by floor";
	$resfl = $db->query($sfl);
	while ($florr = $db->fetch_array($resfl))
	{?>
		<optgroup label="Piso <?php echo $florr['floor']  ?>">
	<?php
		$sql = "SELECT rowid, entity, label, leftpos, toppos, floor FROM ".MAIN_DB_PREFIX."takepos_floor_tables where floor = ".((int) $florr['floor'] );
		$resql = $db->query($sql);
		$rows = array();
		while ($row = $db->fetch_array($resql)) {
			?>
			<option value="<?php echo $row['rowid']  ?>" <?php if($Lug[0]==$row['rowid']){ echo "selected"; } ?>><?php echo $row['label']  ?></option>
			<?php
		}
		?>
		</optgroup>
	<?php
	}
	?>
	
</select><br><br>-->
<!--<p class="center">
<button onclick="SendOrder()" value="Sendorder">Enviar</button>
</p>-->
<?php
/*$constFreeText = 'TAKEPOS_FOOTER'.$_SESSION['takeposterminal'];
if (!empty($conf->global->TAKEPOS_FOOTER) || !empty($conf->global->{$constFreeText})) {
	$newfreetext = '';
	$substitutionarray = getCommonSubstitutionArray($langs);
	if (!empty($conf->global->{$constFreeText})) {
		$newfreetext .= make_substitutions($conf->global->{$constFreeText}, $substitutionarray);
	}
	if (!empty($conf->global->TAKEPOS_FOOTER)) {
		$newfreetext .= make_substitutions($conf->global->TAKEPOS_FOOTER, $substitutionarray);
	}
	print $newfreetext;
}*/
?>

<script>
window.print();
</script>
</body>
<script src="<?php echo DOL_URL_ROOT?>/includes/jquery/js/jquery.min.js?layout=classic&amp;version=14.0.5"></script>
</html>
