<?php
/* Copyright (C) 2001-2005 Rodolphe Quiedeville <rodolphe@quiedeville.org>
 * Copyright (C) 2004-2015 Laurent Destailleur  <eldy@users.sourceforge.net>
 * Copyright (C) 2005-2012 Regis Houssin        <regis.houssin@inodbox.com>
 * Copyright (C) 2015      Jean-François Ferry	<jfefe@aternatik.fr>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */



// Load Dolibarr environment
$res = 0;
// Try main.inc.php into web root known defined into CONTEXT_DOCUMENT_ROOT (not always defined)
if (!$res && !empty($_SERVER["CONTEXT_DOCUMENT_ROOT"])) $res = @include $_SERVER["CONTEXT_DOCUMENT_ROOT"]."/main.inc.php";
// Try main.inc.php into web root detected using web root calculated from SCRIPT_FILENAME
$tmp = empty($_SERVER['SCRIPT_FILENAME']) ? '' : $_SERVER['SCRIPT_FILENAME']; $tmp2 = realpath(__FILE__); $i = strlen($tmp) - 1; $j = strlen($tmp2) - 1;
while ($i > 0 && $j > 0 && isset($tmp[$i]) && isset($tmp2[$j]) && $tmp[$i] == $tmp2[$j]) { $i--; $j--; }
if (!$res && $i > 0 && file_exists(substr($tmp, 0, ($i + 1))."/main.inc.php")) $res = @include substr($tmp, 0, ($i + 1))."/main.inc.php";
if (!$res && $i > 0 && file_exists(dirname(substr($tmp, 0, ($i + 1)))."/main.inc.php")) $res = @include dirname(substr($tmp, 0, ($i + 1)))."/main.inc.php";
// Try main.inc.php using relative path
if (!$res && file_exists("../main.inc.php")) $res = @include "../main.inc.php";
if (!$res && file_exists("../../main.inc.php")) $res = @include "../../main.inc.php";
if (!$res && file_exists("../../../main.inc.php")) $res = @include "../../../main.inc.php";
if (!$res) die("Include of main fails");

/*echo "<pre>";
print_r($_POST);
exit;*/
// Get parameters
$action = GETPOST('action', 'aZ09');
$id = GETPOST('id', 'int');

if($action == "SendOrder")
{
	$Resp = array();
	
	$linesid = GETPOST('linesid', 'array');
	
	$place = GETPOST('Lugar', 'int');
	
	$facid = GETPOST('facid', 'int');
	
	$status = GETPOST('status', 'int');

	// Insertion dans base de la ligne
	$sql = 'INSERT INTO '.MAIN_DB_PREFIX.'monitor_comandas_orders';
	$sql .= ' (fk_facture, place, fk_user_author, datec, status';
	$sql .= ')';
	$sql .= " VALUES ('".$facid."', ";
	$sql .= " '".$place."', ";
	$sql .= " '".$user->id."', ";
	$sql .= " NOW(), ";
	$sql .= " 1 ";
	$sql .= ')';
	
	//echo "<pre>";
	//print_r($categories);
	//echo $sql;
	//exit;

	$resql = $db->query($sql);

	if ($resql) {
		
		$idi = $db->last_insert_id(MAIN_DB_PREFIX.'monitor_comandas_orders');
		
		
		//========================items===================
			$err = 0;
			foreach($linesid as $line)
			{
				$product = GETPOST('product'.$line, 'aZ09');
				$qty = GETPOST('qtys'.$line, 'int');
				$type = GETPOST('type'.$line, 'int');
				
				$sqlc = 'INSERT INTO '.MAIN_DB_PREFIX.'monitor_comandas_orders_details';
				$sqlc .= ' (fk_order, line_ref, fk_product, qty, type ';
				$sqlc .= ')';
				$sqlc .= " VALUES ('".$idi."',";
				$sqlc .= " '".$line."', ";
				$sqlc .= " '".$product."', ";
				$sqlc .= " '".$qty."', ";
				$sqlc .= " '".$type."' ";
				$sqlc .= ')';
				
				$resqlc = $db->query($sqlc);

				if(!$resqlc)
				{
					$err ++;
				}
			}
			
		//========================items===================
		
		if($err==0)
		{
			$db->commit();
			$Resp["Res"] = "Success";
			$Resp["V"] = "Orden Enviada";
		}
		else {
			$db->rollback();
			$Resp["Res"] = "Error";
			$Resp["V"] = "Error agregando l\u00edneas!!";
		}
		
		
	} else {
		$Resp["Res"] = "Error";
		$Resp["V"] = "Error agregando orden!!";
	}
	
	echo json_encode($Resp);
	exit;
}

if($action == "ListOrder")
{
	
	 



	/*$sqlu = "ALTER TABLE `llx_monitor_comandas_orders`";
	$sqlu .= "ADD COLUMN `Upd` enum('N','Y') NOT NULL DEFAULT 'N' AFTER `status`,";
	$sqlu .= "ADD COLUMN `UpdDate` datetime NULL AFTER `Upd`;";
	$resqlu = $db->query($sqlu);*/
			
			
	$monitor = GETPOST('monitor', 'int');
	$last = GETPOST('last', 'int');
	
	$categorys = array();
	
	$smc = "SELECT fk_categorie from ".MAIN_DB_PREFIX."monitor_comandas_categorie where fk_monitor = '".$monitor."' ";
			
	$resmc = $db->query($smc);
	if ($resmc)
	{
		$nuc = $db->num_rows($resmc);
		$c = 0;
		while ($c < $nuc)
		{
			$obm = $db->fetch_object($resmc);
			if ($obm)
			{
				$categorys[]= $obm->fk_categorie;	
			}
			$c++;
		}
	}
	//echo "<pre>";
	//print_r($categorys);
	
	$orders = array("c" => 0, "cu" => 0, "l" => $last, "orders" => array(), "ordersu" => array());
	
	//======================News Orders========================
	$sql = 'SELECT fl.rowid as place_id, fl.label as place_label, t.rowid as order_id, t.fk_facture';
	$sql .= ' FROM '.MAIN_DB_PREFIX.'monitor_comandas_orders as t join '.MAIN_DB_PREFIX.'takepos_floor_tables fl on t.place = fl.rowid where t.status = 1 AND t.rowid > '.$last.' order by t.rowid ASC';

	$resql = $db->query($sql);
	if ($resql)
	{
		$num = $db->num_rows($resql);
		$i = 0;
		$o = 0;
		while ($i < $num)
		{
			
			$obj = $db->fetch_object($resql);
			if ($obj)
			{
				
				$details = array();
				$sqd = " select mc.rowid as line_id, pr.label as pr_label, mc.qty, ifnull(mc.qty_check,0) as qty_check, mc.type, (select group_concat(fk_categorie) from ".MAIN_DB_PREFIX."categorie_product where fk_product = pr.rowid) as categories,  ifnull((select monitor from ".MAIN_DB_PREFIX."product_extrafields where fk_object = pr.rowid),'') as monitor";
				$sqd .= " FROM ".MAIN_DB_PREFIX."monitor_comandas_orders_details mc join ".MAIN_DB_PREFIX."product pr on mc.fk_product = pr.rowid where mc.fk_order = '".$obj->order_id."'  AND ifnull(mc.qty_check,0) <> mc.qty order by mc.type, pr_label";
					//echo $sqd."<br><br><br>";
				$resqd = $db->query($sqd);
				if ($resqd)
				{
					//echo "hooo";
					$nud = $db->num_rows($resqd);
					$j = 0;
					while ($j < $nud)
					{
						
						$obd = $db->fetch_object($resqd);
						if ($obd)
						{
							
							//Validacion por categorias
							$categs = explode(",", $obd->categories);
							//print_r($categs);
							$pass = false;
							if($obd->monitor !="" && $obd->monitor != 0 && $obd->monitor == $monitor)
							{
								$pass = true;
							}
							if(!$pass)
							{
								foreach($categs as $cat)
								{
									if(in_array($cat, $categorys))
									{
										$pass = true;
									}
								}
							}
							//Validacion por categorias
							
							if($pass)
							{
								$details[] = $obd;
							}
						}
						$j++;
					}
				}
				
				if(count($details)>0)
				{
					$orders["orders"][] = array("oid" => $obj->order_id, "pid" => $obj->place_id, "plabel" => $obj->place_label, "fac" => $obj->fk_facture,"details" => $details);
					$last = $obj->order_id;
					$o++;
				}
				$i++;
			}
						
		}
		$orders["c"] = $o;
		$orders["l"] = $last;
	}
	//======================News Orders========================
	
	//====================Updates Orders========================
	$sql = "SELECT fl.rowid as place_id, fl.label as place_label, t.rowid as order_id, t.fk_facture, TIME_TO_SEC(TIMEDIFF(NOW(), t.UpdDate)) as UpdDate, t.UpdKey";
	$sql .= " FROM ".MAIN_DB_PREFIX."monitor_comandas_orders as t join ".MAIN_DB_PREFIX."takepos_floor_tables fl on t.place = fl.rowid where  t.Upd = 'Y' order by t.rowid ASC";
	//echo $sql;
	$resql = $db->query($sql);
	if ($resql)
	{

		$num = $db->num_rows($resql);
		$i = 0;
		$o = 0;
		while ($i < $num)
		{
			
			$obj = $db->fetch_object($resql);
			if ($obj)
			{
				//echo "<pre>";
				//print_r($obj);
				$details = array();
				$sqd = " select mc.rowid as line_id, pr.label as pr_label, mc.qty, ifnull(mc.qty_check,0) as qty_check, mc.type, (select group_concat(fk_categorie) from ".MAIN_DB_PREFIX."categorie_product where fk_product = pr.rowid) as categories,  ifnull((select monitor from ".MAIN_DB_PREFIX."product_extrafields where fk_object = pr.rowid),'') as monitor";
				$sqd .= " FROM ".MAIN_DB_PREFIX."monitor_comandas_orders_details mc join ".MAIN_DB_PREFIX."product pr on mc.fk_product = pr.rowid where mc.fk_order = '".$obj->order_id."' order by mc.type, pr_label";
					//echo $sqd."<br><br><br>";
				$resqd = $db->query($sqd);
				if ($resqd)
				{
					//echo "hooo";
					$nud = $db->num_rows($resqd);
					$j = 0;
					while ($j < $nud)
					{
						
						$obd = $db->fetch_object($resqd);
						if ($obd)
						{
							
							//Validacion por categorias
							$categs = explode(",", $obd->categories);
							//print_r($categs);
							$pass = false;
							if($obd->monitor !="" && $obd->monitor != 0 && $obd->monitor == $monitor)
							{
								$pass = true;
							}
							if(!$pass)
							{
								foreach($categs as $cat)
								{
									if(in_array($cat, $categorys))
									{
										$pass = true;
									}
								}
							}
							//Validacion por categorias
							
							if($pass)
							{
								$details[] = $obd;
							}
						}
						$j++;
					}
				}
				
				if(count($details)>0)
				{
					$orders["ordersu"][] = array("oid" => $obj->order_id, "pid" => $obj->place_id, "plabel" => $obj->place_label, "fac" => $obj->fk_facture, "UpdKey" => $obj->UpdKey, "details" => $details);
					$last = $obj->order_id;
					
					if($obj->UpdDate >= 10)
					{
						$sqlu = "UPDATE ".MAIN_DB_PREFIX."monitor_comandas_orders";
						$sqlu .= " set Upd = 'N' where rowid = '".$obj->order_id."'";
						$resqlu = $db->query($sqlu);
					}
				
					$o++;
				}
				
				
				
				$i++;
			}
						
		}
		$orders["cu"] = $o;
		
		
		
	}
	//====================Updates Orders========================
	
	echo json_encode($orders);
	exit;
}

if($action == "CheckOrder")
{
	$Resp = array();
	$order_id = GETPOST('order_id', 'int');
	$Check = GETPOST('Check', 'aZ09');
	
	if($_POST['line_id']=="ALL")
		$line_id = GETPOST('line_id', 'aZ09');
	else
		$line_id = GETPOST('line_id', 'int');
	
	$units = GETPOST('units', 'int');
	
	$lines_all = GETPOST('lines_all', 'array');
	
	if($line_id!="ALL")
	{
		
		$sul = " select qty  ";
		$sul .= " FROM ".MAIN_DB_PREFIX."monitor_comandas_orders_details mc join ".MAIN_DB_PREFIX."product pr on mc.fk_product = pr.rowid where mc.rowid = '".$line_id."' AND mc.fk_order = '".$order_id."'";
			
					//echo $sqd."<br><br><br>";
		$resul = $db->query($sul);
		
		$osul = $db->fetch_object($resul);
		
		$ql = " qty ";
		if($units!=-1)
			$ql = $osul->qty - $units;
		
		
		if($Check == "YES" || ($units!=-1 && $ql != $osul->qty))
		{
			$sql = "UPDATE ".MAIN_DB_PREFIX."monitor_comandas_orders_details";
			$sql .= " set qty_check = ".$ql." , fk_user_check = '".$user->id."', date_check = now() where rowid = '".$line_id."' AND fk_order = '".$order_id."'";
		}
		else
		{
			$sql = "UPDATE ".MAIN_DB_PREFIX."monitor_comandas_orders_details";
			$sql .= " set qty_check = 0 , fk_user_check = '', date_check = '0000-00-00 00:00:00' where rowid = '".$line_id."' AND fk_order = '".$order_id."'";
			
		}
//echo $units.$sql;
		
		$resql = $db->query($sql);
		if ($resql)
		{
			if($Check == "YES")
			{
				$sqd = " select count(*) as cant ";
				$sqd .= " FROM ".MAIN_DB_PREFIX."monitor_comandas_orders_details mc join ".MAIN_DB_PREFIX."product pr on mc.fk_product = pr.rowid where fk_order = '".$order_id."' AND qty <> ifnull(qty_check,0) ";
				
				$resqd = $db->query($sqd);
				$obd = $db->fetch_object($resqd);
				
				if($obd->cant==0)
				{
					$keyudp = genera_codigo(10);
					$sql = "UPDATE ".MAIN_DB_PREFIX."monitor_comandas_orders";
					$sql .= " set status = '2', Upd = 'Y', UpdDate = NOW(), UpdKey = '".$keyudp."' where rowid = '".$order_id."'";
				
					$resql = $db->query($sql);
				}
				else
				{
						$keyudp = genera_codigo(10);
					$sql = "UPDATE ".MAIN_DB_PREFIX."monitor_comandas_orders";
					$sql .= " set Upd = 'Y', UpdDate = NOW(), UpdKey = '".$keyudp."' where rowid = '".$order_id."'";
				
					$resql = $db->query($sql);
				}

			}
			else
			{
				$keyudp = genera_codigo(10);
				$sql = "UPDATE ".MAIN_DB_PREFIX."monitor_comandas_orders";
				$sql .= " set status = '1', Upd = 'Y', UpdDate= NOW(), UpdKey = '".$keyudp."' where rowid = '".$order_id."'";
				
				$resql = $db->query($sql);
			}
		}
	}
	else
	{
		/*$st = 1;
		if($Check == "YES")
		{
			$st = 2;
		}
		$keyudp = genera_codigo(10);
		$sql = "UPDATE ".MAIN_DB_PREFIX."monitor_comandas_orders";
		$sql .= " set status = '".$st."', Upd = 'Y', UpdDate= NOW(), UpdKey = '".$keyudp."' where rowid = '".$order_id."'";
	
	
		$resql = $db->query($sql);
	
		if ($resql)
		{*/
			$sqd = " select mc.rowid as line_id ";
			$sqd .= " FROM ".MAIN_DB_PREFIX."monitor_comandas_orders_details mc join ".MAIN_DB_PREFIX."product pr on mc.fk_product = pr.rowid where mc.fk_order = '".$order_id."' AND mc.rowid in ('".implode("','", $lines_all)."')";
			
					//echo $sqd."<br><br><br>";
				$resqd = $db->query($sqd);
				if ($resqd)
				{
					//echo "hooo";
					$nud = $db->num_rows($resqd);
					$j = 0;
					while ($j < $nud)
					{
						
						$obd = $db->fetch_object($resqd);
						if ($obd)
						{
							if($Check == "YES")
							{
							$sqf = "UPDATE ".MAIN_DB_PREFIX."monitor_comandas_orders_details";
							$sqf .= " set qty_check = qty, fk_user_check = '".$user->id."', date_check = now() where rowid = '".$obd->line_id."' AND fk_order = '".$order_id."'";
							}
							else {
								$sqf = "UPDATE ".MAIN_DB_PREFIX."monitor_comandas_orders_details";
							$sqf .= " set qty_check = 0, fk_user_check = '', date_check = '0000-00-00 00:00:00' where rowid = '".$obd->line_id."' AND fk_order = '".$order_id."'";
							}
							
							
							$resf = $db->query($sqf);
						}
						$j++;
					}
				}
				
				
				$sqd = " select count(*) as cont ";
				$sqd .= " FROM ".MAIN_DB_PREFIX."monitor_comandas_orders_details mc join ".MAIN_DB_PREFIX."product pr on mc.fk_product = pr.rowid where mc.fk_order = '".$order_id."' AND ifnull(mc.qty_check,0) <> mc.qty";
			
					//echo $sqd."<br><br><br>";
				$resqd = $db->query($sqd);
				
				$obd = $db->fetch_object($resqd);
				
				$st = 1;
				if($Check == "YES" && $obd->cont == 0) //Si totod esta listo lo marco
				{
					$st = 2;
				}
				
				$keyudp = genera_codigo(10);
				$sql = "UPDATE ".MAIN_DB_PREFIX."monitor_comandas_orders";
				$sql .= " set status = '".$st."', Upd = 'Y', UpdDate= NOW(), UpdKey = '".$keyudp."' where rowid = '".$order_id."'";
				$resqd = $db->query($sql);
		//}
	}
	
	/*$sqlh = 'SELECT  Upd, UpdDate';
	$sqlh .= ' FROM '.MAIN_DB_PREFIX.'monitor_comandas_orders as t where rowid = '.$order_id;

	$resqlh = $db->query($sqlh);
	$objh = $db->fetch_object($resqlh);*/
	
	$Resp["Res"] = "OK";
	//$Resp["Ord"] = $objh;
	
	echo json_encode($Resp);
	exit;
	
}

function numero_aleatorio ($ninicial, $nfinal) {
    $numero = rand($ninicial, $nfinal);

    return $numero;
}

function genera_codigo($longitud) 
{
    $caracteres = array("0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z");
    $codigo = '';

    for ($i = 1; $i <= $longitud; $i++) {
        $codigo .= $caracteres[numero_aleatorio(0, 35)];
    }

    return $codigo;
}