<?php
/* Copyright (C) 2017  Laurent Destailleur <eldy@users.sourceforge.net>
 * Copyright (C) 2020  Lenin Rivas		   <lenin@leninrivas.com>
 * Copyright (C) ---Put here your own copyright and developer email---
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <http://www.gnu.org/licenses/>.
 */

 if($action=="addlinerule")
{
	$db->begin();
	
	$categories = GETPOST('categories', 'array');
	
	$titulo = GETPOST('titulo', 'alpha');

	$status = GETPOST('status', 'int');

	// Insertion dans base de la ligne
	$sql = 'INSERT INTO '.MAIN_DB_PREFIX.'monitor_comandas';
	$sql .= ' (titulo, status';
	$sql .= ')';
	$sql .= " VALUES ('".$titulo."',";
	$sql .= " '".$status."'";
	$sql .= ')';
	
	//echo "<pre>";
	//print_r($categories);
	//echo $sql;
	//exit;

	dol_syslog("monitorcomandas::insert", LOG_DEBUG);
	$resql = $db->query($sql);

	if ($resql) {
		
		$idi = $db->last_insert_id(MAIN_DB_PREFIX.'monitor_comandas');
		
		
		//========================CATEGORIES===================
			$err = 0;
			foreach($categories as $category)
			{
				$sqlc = 'INSERT INTO '.MAIN_DB_PREFIX.'monitor_comandas_categorie';
				$sqlc .= ' (fk_categorie, fk_monitor';
				$sqlc .= ')';
				$sqlc .= " VALUES ('".$category."',";
				$sqlc .= " '".$idi."'";
				$sqlc .= ')';
				
				$resqlc = $db->query($sqlc);

				if(!$resqlc)
				{
					$err ++;
				}
			}
			
		//========================CATEGORIES===================
		
		if($err==0)
		{
			//setEventMessages($langs->trans("RecordModifiedSuccessfully"), null, 'mesgs');
			setEventMessages($langs->trans("RecorAddedSuccessfully"), null, 'mesgs');
			$db->commit();
			return 1;
		}
		else {
			setEventMessages($db->error, $db->errors, 'errors');
			$db->rollback();
			return -1;
		}
		
		
	} else {
		setEventMessages($db->error, $db->errors, 'errors');
		$db->rollback();
		return -1;
	}

}

// Action to update record
if ($action == 'updatelinerule')
{
	$db->begin();

	$categories = GETPOST('categories', 'array');
	
	$titulo = GETPOST('titulo', 'alpha');

	$status = GETPOST('status', 'int');

	// Insertion dans base de la ligne
	$sql = "UPDATE ".MAIN_DB_PREFIX."monitor_comandas";
	$sql .= " set titulo = '".$titulo."', status = '".$status."' where rowid = '".$lineid."'";

	//echo $sql;
	//exit;

	dol_syslog("monitorcomandas::update", LOG_DEBUG);
	$resql = $db->query($sql);

	if ($resql) {
		
		//========================CATEGORIES===================
		$sqlc = " DELETE FROM ".MAIN_DB_PREFIX."monitor_comandas_categorie ";
		$sqlc .= " where fk_monitor = '".$lineid."' ";
		$resql = $db->query($sqlc);
		
			$err = 0;
			foreach($categories as $category)
			{
				$sqlc = 'INSERT INTO '.MAIN_DB_PREFIX.'monitor_comandas_categorie';
				$sqlc .= ' (fk_categorie, fk_monitor';
				$sqlc .= ')';
				$sqlc .= " VALUES ('".$category."',";
				$sqlc .= " '".$lineid."'";
				$sqlc .= ')';
				
				$resqlc = $db->query($sqlc);

				if(!$resqlc)
				{
					$err ++;
				}
			}
			
		//========================CATEGORIES===================
		
		

		
		
		if($err==0)
		{
			//setEventMessages($langs->trans("RecordModifiedSuccessfully"), null, 'mesgs');
			setEventMessages($langs->trans("RecordModifiedSuccessfully"), null, 'mesgs');
			$db->commit();
			return 1;
		}
		else {
			setEventMessages($db->error, $db->errors, 'errors');
			$db->rollback();
			return -1;
		}
		
	} else {
		setEventMessages($db->error, $db->errors, 'errors');
		$db->rollback();
		return -1;
	}
}

// Remove a line
if ($action == 'confirm_deleteline' )
{
	$db->begin();

	$fields = json_encode(GETPOST('fields', 'array'));
	$accione = GETPOST('accione', 'alpha');
	$campo_condi= GETPOST('vale', 'alpha');
	$condicion= GETPOST('condicion', 'alpha');
	$valor = GETPOST('vali', 'alpha');
	$status = GETPOST('status', 'int');
	
	$sqlc = " DELETE FROM ".MAIN_DB_PREFIX."monitor_comandas_categorie ";
	$sqlc .= " where fk_monitor = '".$lineid."' ";

	$resqlc = $db->query($sqlc);

	// Insertion dans base de la ligne
	$sql = " DELETE FROM ".MAIN_DB_PREFIX."monitor_comandas ";
	$sql .= " where rowid = '".$lineid."' ";


	dol_syslog("monitorcomandas::delete", LOG_DEBUG);
	$resql = $db->query($sql);

	if ($resql) {
	
		
		setEventMessages($langs->trans("RecordDeletedSuccessfully"), null, 'mesgs');

		$db->commit();
		return 1;
	} else {
		setEventMessages($db->error, $db->errors, 'errors');
		$db->rollback();
		return -1;
	}
}
