<?php
/* Copyright (C) 2001-2005 Rodolphe Quiedeville <rodolphe@quiedeville.org>
 * Copyright (C) 2004-2015 Laurent Destailleur  <eldy@users.sourceforge.net>
 * Copyright (C) 2005-2012 Regis Houssin        <regis.houssin@inodbox.com>
 * Copyright (C) 2015      Jean-François Ferry	<jfefe@aternatik.fr>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */



// Load Dolibarr environment
$res = 0;
// Try main.inc.php into web root known defined into CONTEXT_DOCUMENT_ROOT (not always defined)
if (!$res && !empty($_SERVER["CONTEXT_DOCUMENT_ROOT"])) $res = @include $_SERVER["CONTEXT_DOCUMENT_ROOT"]."/main.inc.php";
// Try main.inc.php into web root detected using web root calculated from SCRIPT_FILENAME
$tmp = empty($_SERVER['SCRIPT_FILENAME']) ? '' : $_SERVER['SCRIPT_FILENAME']; $tmp2 = realpath(__FILE__); $i = strlen($tmp) - 1; $j = strlen($tmp2) - 1;
while ($i > 0 && $j > 0 && isset($tmp[$i]) && isset($tmp2[$j]) && $tmp[$i] == $tmp2[$j]) { $i--; $j--; }
if (!$res && $i > 0 && file_exists(substr($tmp, 0, ($i + 1))."/main.inc.php")) $res = @include substr($tmp, 0, ($i + 1))."/main.inc.php";
if (!$res && $i > 0 && file_exists(dirname(substr($tmp, 0, ($i + 1)))."/main.inc.php")) $res = @include dirname(substr($tmp, 0, ($i + 1)))."/main.inc.php";
// Try main.inc.php using relative path
if (!$res && file_exists("../main.inc.php")) $res = @include "../main.inc.php";
if (!$res && file_exists("../../main.inc.php")) $res = @include "../../main.inc.php";
if (!$res && file_exists("../../../main.inc.php")) $res = @include "../../../main.inc.php";
if (!$res) die("Include of main fails");

$monitor = GETPOST('monitor', 'int');

	
	$sqm = "SELECT titulo from ".MAIN_DB_PREFIX."monitor_comandas where rowid = '".$monitor."' ";
			
	$resmc = $db->query($sqm);
	if ($resmc)
	{
		$nuc = $db->num_rows($resmc);
		$c = 0;
		
			$obm = $db->fetch_object($resmc);
		
	}
	
?>
<html>
	<head>
		<title><?php echo $obm->titulo; ?></title>
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<meta charset="UTF-8">
		<!--remember to go back and download actual files for this at https://google.github.io/material-design-icons/-->
		<link rel="stylesheet" media="screen" href="src/monitor.css" />
<link rel="stylesheet" href="../../takepos/css/colorbox.css" type="text/css" media="screen" />

</head>
	
<?php
if ($conf->global->TAKEPOS_COLOR_THEME == 1) {
	print '<link rel="stylesheet" href="../../takepos/css/colorful.css">';
}
?>

	<body onload="ListOrder()">
		<header>
</header>
	<nav>
	<table width="100%">
		<tr>
			<td width="33%">
				&nbsp;
			</td>
			<td width="33%" align="center">
				<b><?php echo  $obm->titulo; ?></b>
			</td>
			<td width="33%" align="right">
				<img class="manito" onclick="CleanOrders()" width="25" title="<?php print $langs->trans("clean_orders_"); ?>" src = "img/eraser.png" />
			</td>
		</tr>
	</table>
	</nav>
<main class="main">
	<div id = "list" class="grid-layout">
		<!--<div class="grid-item">item 2</div>-->
	</div>
</main>
	</body>
	
<script>

function PrintOrder(orderid, facture){
	
	$.colorbox({href:"<?php echo DOL_URL_ROOT; ?>/custom/monitorcomandas/orden_print.php?facid="+facture+"&orderid="+orderid+"&monitor=<?php echo $monitor?>", width:"60%", height:"80%", transition:"none", iframe:"true", title:"Orden"});
}

var last = 0;
var ok = true;
function ListOrder()
{
	if(ok)
	{
		ok = false;
		$.ajax({
		    type: "POST",
		    url: "ajax/monitor_comandas.php",
		    data: { token: '<?php echo currentToken(); ?>', action: "ListOrder", monitor: "<?php echo $monitor?>", last: last },
		    success: function(data, status, xhr) {
		        var obj = JSON.parse(data); //if the dataType is not specified as json uncomment this
		        //console.log(obj);
		        
		        if(Number(obj.c)==0) //no hay ordenes
		        {
		        	ok = true;//setTimeout(ListOrder(), 5000);
		        }
		        if(Number(obj.c) > 0)
		        {
		        	ShowOrders(obj);
		        }
		        if(Number(obj.cu) > 0)
		        {
		        	ShowOrders(obj,"u");
		        }
		       
		    },
		    error: function() {
		        //alert('error handling here');
		    }
		});
	}
	
}

var platesab = new Object();
platesab["1"] = "<?php print $langs->trans("Entrantes_Abr"); ?>";
platesab["2"] = "<?php print $langs->trans("Primer_plato_Abr"); ?>";
platesab["3"] = "<?php print $langs->trans("Segundo_plato_Abr"); ?>";
platesab["4"] = "<?php print $langs->trans("Postre_Abr"); ?>";
				
var plates = new Object();
plates["1"] = "<?php print $langs->trans("Entrantes"); ?>";
plates["2"] = "<?php print $langs->trans("Primer_plato"); ?>";
plates["3"] = "<?php print $langs->trans("Segundo_plato"); ?>";
plates["4"] = "<?php print $langs->trans("Postre"); ?>";

function ShowOrders(obj, tp = "o")
{
	
	
	if(tp == "o")
	{
		var ords = obj.orders;
	}
	else
	{
		var ords = obj.ordersu
	}
	
	for(var order of ords)
	{
		var head = '';
		var body = '';
		var UpdKey = "";
		if(tp == "o")
		{
			head += '<div id="order_'+order.oid+'" order="'+order.oid+'" class="grid-item">';
		}
		else
		{
			if(order.UpdKey != $('#UpdKey_'+order.oid).val())
				UpdKey = order.UpdKey;
			else
				continue;
		}
		
		head += '<table width="100%" class="grid-itemtable"><tr><td><img class="manito" width="18" id="PrintOrder_'+order.oid+'" onclick="PrintOrder('+order.oid+','+order.fac+' )" title="<?php print $langs->trans("Print_order_comm"); ?> src = "img/printing.png" /></td>';
		head += '<td align="center"><?php print $langs->trans("table_comm"); ?> '+order.plabel+'</td>';
		head += '<td align="right"><img class="manito" width="18" id="checkAll_'+order.oid+'" onclick="CheckAllDetail('+order.oid+')" title="<?php print $langs->trans("Ready_order"); ?>" src = "img/circle-icon.png" /><input type="hidden" id ="ischeckAll_'+order.oid+'" value="NO" /><input type="hidden" id ="UpdKey_'+order.oid+'" value="'+UpdKey+'" /></td></tr></table>';
		head += '<br/>';
		
		
		body = '<table cellspacing="0" cellpadding="1" width = "100%"  class="table-prods grid-itemtable">';
		var raws = 0;
		for(var detail of order.details)
		{
			var restund = -1;
			var imgi = "img/circle-icon.png";
			var ick = "NO";
			var tach = "";
			
			//console.log(detail);
			body += '<tr >';
			
			
			
			if(Number(detail.qty_check)!=0)
				restund = Number(detail.qty)-Number(detail.qty_check);
			
			if(restund==0)
			{
				imgi = "img/check-icon.png";
				ick = "YES";
				tach = ' class = "tached" ';
			}
				
			body += '<td width="1%"  valign="middle"><img width="18" class="manito" id="check_'+order.oid+'_'+detail.line_id+'" onclick="CheckDetail('+order.oid+', '+detail.line_id+')" src = "'+imgi+'" /><input type="hidden" id ="ischeck_'+order.oid+'_'+detail.line_id+'" value="'+ick+'" /><input type="hidden" id ="det_'+order.oid+'_'+raws+'" value="'+detail.line_id+'" /></td>';
			
			if(detail.type!=0)
				body += '<td width="1%" valign="middle"><small class=" manito badge badge-plate" title="'+plates[detail.type]+'">'+platesab[detail.type]+'</small></td>';
			else
				body += '<td width="1%" valign="middle"></td>';
				
			body += '<td  width="1%" valign="middle">';
			body += '<input type="hidden" id ="qtyorg_'+order.oid+'_'+detail.line_id+'" value="'+detail.qty+'" />';
			
			
			
			
			body += '<select id="qty_'+order.oid+'_'+detail.line_id+'" onchange="CheckDetail('+order.oid+', '+detail.line_id+', \'UNIT\')">';
			
			for(var qt = Number(detail.qty); qt>=0; qt--)
			{
				var selec = "";
					if(Number(detail.qty_check)!=0 && qt == restund)
						selec = "selected";
				
				body += '<option value="'+qt+'" '+selec+'>'+qt+'</option>';
			}
			body += '</select></td>';
			

			body += '<td valign="middle" id="pr_label_'+order.oid+'_'+detail.line_id+'" '+tach+'>'+detail.pr_label+'</td>';
			body += '</tr>';
			raws++;
		}
		body += '</table><input type = "hidden" id = "raws_'+order.oid+'" value= "'+raws+'">';
		
		if(tp == "o")
		{
			head += body+'</div>';
			$("#list").append(head);
		}
		else
		{
			$('#order_'+order.oid).html(head+body);
			CheckUp(order.oid);
		}
	}
	
	
	//order += '<div align="left">Mesa 1</div>';
	
	//$("#list").append(head);
	
	if(tp == "o")
	{
		last = obj.l;
	}
	ok = true;
	
}

function CleanOrders()
{
	var orders = document.querySelectorAll(".grid-item");
	if(confirm("<?php print $langs->trans("confirm_clean"); ?>"))
	{
		for(var orderdat of orders)
		{
			var orderid = orderdat.attributes.order.nodeValue;
			if($("#ischeckAll_"+orderid).val()=="YES")
			{
				$("#order_"+orderid).remove();
			}
	
		}
	}
}

var lines_all = [];
function CheckOrder(order_id, line_id = "ALL", units = -1)
{
	if(line_id == "ALL")
	{
		var Check = $("#ischeckAll_"+order_id).val();
	}
	else
	{
		var Check = $("#ischeck_"+order_id+"_"+line_id).val();
	}
	
	$.ajax({
		type: "POST",
		url: "ajax/monitor_comandas.php",
		data: { token: '<?php echo currentToken(); ?>', action: "CheckOrder", order_id: order_id, line_id: line_id, units: units, Check: Check, lines_all: lines_all },
		success: function(data, status, xhr) {
			var obj = JSON.parse(data); //if the dataType is not specified as json uncomment this
			if(obj.Res == "OK" && line_id!="ALL")
			{
				CheckUp(order_id);
			}
		    
		       
		},
		error: function() {
			//alert('error handling here');
		}
		});
}

function CheckUp(order_id)
{
	for(var h = 0; h < Number($("#raws_"+order_id).val()); h++)
	{
		var deta = $("#det_"+order_id+'_'+h).val();
		
		if($("#ischeck_"+order_id+"_"+deta).val() == "NO")
		{
			$("#ischeckAll_"+order_id).val("NO");
			$("#checkAll_"+order_id).attr("src" ,"img/circle-icon.png");
			return;
		}
	}
	
	$("#ischeckAll_"+order_id).val("YES");
	$("#checkAll_"+order_id).attr("src" ,"img/check-icon.png");
}

function CheckAllDetail(order_id)
{
	lines_all = [];
	//console.log("1=>"+$("#ischeckAll_"+order_id).val());
	if($("#ischeckAll_"+order_id).val()=="NO")
	{
		$("#ischeckAll_"+order_id).val("YES");
		$("#checkAll_"+order_id).attr("src" ,"img/check-icon.png");
	}
	else
	{
		$("#ischeckAll_"+order_id).val("NO");
		$("#checkAll_"+order_id).attr("src" ,"img/circle-icon.png");
	}
	
	for(var h = 0; h < Number($("#raws_"+order_id).val()); h++)
	{
		var deta = $("#det_"+order_id+'_'+h).val();
		if($("#ischeckAll_"+order_id).val() == "NO")
			$("#ischeck_"+order_id+"_"+deta).val("YES");
		else
			$("#ischeck_"+order_id+"_"+deta).val("NO");
		CheckDetail(order_id, deta, "ALL");
		
		lines_all.push(deta);

	}
	
	//console.log("12=>"+$("#ischeckAll_"+order_id).val());
	CheckOrder(order_id);
}

function CheckDetail(order_id, line_id, Tp="ONE")
{
	var units = -1;
	if(Tp == "UNIT")
	{
		units = Number($("#qty_"+order_id+"_"+line_id).val());
		
		if(units == 0)
			$("#ischeck_"+order_id+"_"+line_id).val("NO");
		else
			$("#ischeck_"+order_id+"_"+line_id).val("YES");
	}
	
	if(units != -1 || Tp!="UNIT")
	{
		if($("#ischeck_"+order_id+"_"+line_id).val()=="NO")
		{
			$("#ischeck_"+order_id+"_"+line_id).val("YES");
			$("#check_"+order_id+"_"+line_id).attr("src" ,"img/check-icon.png");
			$("#pr_label_"+order_id+"_"+line_id).addClass("tached");
			$("#qty_"+order_id+"_"+line_id).val(0);
		}
		else
		{
			$("#ischeck_"+order_id+"_"+line_id).val("NO");
			$("#check_"+order_id+"_"+line_id).attr("src" ,"img/circle-icon.png");
			$("#pr_label_"+order_id+"_"+line_id).removeClass("tached");
			//console.log("====>"+units);
			if(units==0 || units == -1)
				$("#qty_"+order_id+"_"+line_id).val($("#qtyorg_"+order_id+"_"+line_id).val());
		}
	}
	
	if(Tp == "ONE")
	{
		CheckOrder(order_id, line_id);
	}
	else if(Tp == "UNIT")
	{
		
		CheckOrder(order_id, line_id, units)
	}
}

//ListOrder();
setInterval(ListOrder, 1000);

/**
"nav" uses position: sticky. If a browser (Edge 15, IE 11) doesn't support position: sticky, then we'll use position: fixed (class .is-fixed), depending on the pageYOffset property.
Note: IE11 uses pageYOffset, which is the same as scrollY (CSSOM View Module) in modern browsers. See also <http://caniuse.com/#feat=css-sticky> for browser support.
*/

function init() {
  const nav = document.querySelector('nav');
  const isSticky = window.getComputedStyle(nav).position == 'sticky';
  const headerHeight = document.querySelector('header').offsetHeight;
  let latestKnownScrollY = 0, ticking = false, isDone = false;

  let update = function () {
    const cls = nav.classList;    
    if (latestKnownScrollY >= headerHeight && !isDone) {
      if (!isSticky) cls.add("is-fixed"); // IE11 and Edge 15
      cls.add("is-scrolled");
      isDone = true;
    } else if (latestKnownScrollY < headerHeight && isDone) {
      if (!isSticky) cls.remove("is-fixed");
      cls.remove("is-scrolled");
      isDone = false;
    }
    // allow further rAFs to be called
    ticking = false;
  };

  /* See:
<https://www.html5rocks.com/en/tutorials/speed/animations/#debouncing-scroll-events> */
  let onScroll = function () {
    latestKnownScrollY = window.pageYOffset;
    if (!ticking) {
      requestAnimationFrame(update);
      ticking = true;
    }
  };

  window.addEventListener('scroll', onScroll, false);
}

document.addEventListener('DOMContentLoaded', init, false);

/* 2020-02-26 - Added Intersection Observer which works basically in all browsers except IE. See browser support at
 https://caniuse.com/#feat=intersectionobserver
*/
if ('IntersectionObserver' in window) {
  const options = {
    root: null,
    rootMargin: "-50px 0px -400px",
    threshold: 1
  };

  const links = document.querySelectorAll('nav a');

  let intersectHandler = function (entries) {
    entries.forEach(function (entry) {
      if (entry.isIntersecting) {
        links.forEach(function (a) {
          if (a.textContent == entry.target.textContent) {
            a.classList.add('is-selected');
          } else {
            a.classList.remove('is-selected');
          }
        });
      }
    });
  };

  const observer = new IntersectionObserver(intersectHandler, options);

  const targets = document.querySelectorAll('main h3');
  targets.forEach(function (target) {
    observer.observe(target);
  });
}
</script>
<script src="<?php echo DOL_URL_ROOT?>/includes/jquery/js/jquery.min.js?layout=classic&amp;version=14.0.5"></script>
<script type="text/javascript" src="../../takepos/js/jquery.colorbox-min.js"></script>
	</html>