-- Copyright (C) 2019      Laurent Destailleur  <eldy@users.sourceforge.net>
--
-- This program is free software: you can redistribute it and/or modify
-- it under the terms of the GNU General Public License as published by
-- the Free Software Foundation, either version 3 of the License, or
-- (at your option) any later version.
--
-- This program is distributed in the hope that it will be useful,
-- but WITHOUT ANY WARRANTY; without even the implied warranty of
-- MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
-- GNU General Public License for more details.
--
-- You should have received a copy of the GNU General Public License
-- along with this program.  If not, see http://www.gnu.org/licenses/.


CREATE TABLE `llx_monitor_comandas` (
	  `rowid` int(11) NOT NULL AUTO_INCREMENT,
	  `titulo` varchar(100) DEFAULT NULL,
	  `status` int(2) DEFAULT NULL,
	  PRIMARY KEY (`rowid`)
	) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE `llx_monitor_comandas_categorie` (
  `fk_categorie` int(11) NOT NULL,
  `fk_monitor` int(11) NOT NULL,
  `import_key` varchar(14) DEFAULT NULL,
  PRIMARY KEY (`fk_categorie`,`fk_monitor`),
  KEY `idx_categorie_comanda_fk_categorie` (`fk_categorie`),
  KEY `idx_categorie_comanda_fk_monitor` (`fk_monitor`),
  CONSTRAINT `fk_categorie_comanda_categorie_rowid` FOREIGN KEY (`fk_categorie`) REFERENCES `llx_categorie` (`rowid`),
  CONSTRAINT `fk_categorie_comanda_monitor_rowid` FOREIGN KEY (`fk_monitor`) REFERENCES `llx_monitor_comandas` (`rowid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `llx_monitor_comandas_orders` (
  `rowid` int(11) NOT NULL AUTO_INCREMENT,
  `fk_facture` int(11) NOT NULL,
  `place` int(11) NOT NULL,
  `fk_user_author` int(11) DEFAULT NULL,
  `datec` datetime NOT NULL,
  `status` int(11) DEFAULT NULL,
  `Upd` enum('N','Y') NOT NULL DEFAULT 'N',
  `UpdDate` datetime NULL,
  `UpdKey` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`rowid`),
  UNIQUE KEY `orderidx` (`rowid`) USING BTREE,
  KEY `placeidx` (`place`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE `llx_monitor_comandas_orders_details` (
  `rowid` int(11) NOT NULL AUTO_INCREMENT,
  `fk_order` int(11) NOT NULL,
  `line_ref` int(11) DEFAULT NULL,
  `fk_product` int(11) NOT NULL,
  `qty` double DEFAULT NULL,
  `type` int(11) DEFAULT NULL,
  `qty_check` int(11) DEFAULT NULL,
  `fk_user_check` int(11) DEFAULT NULL,
  `date_check` datetime DEFAULT NULL,
  PRIMARY KEY (`rowid`),
  KEY `orderdetidx` (`fk_order`) USING BTREE,
  KEY `productidx` (`fk_product`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;