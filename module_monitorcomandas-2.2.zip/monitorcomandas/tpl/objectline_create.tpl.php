<?php
/* Copyright (C) 2010-2012	Regis Houssin		<regis.houssin@inodbox.com>
 * Copyright (C) 2010-2014	Laurent Destailleur	<eldy@users.sourceforge.net>
 * Copyright (C) 2012-2013	Christophe Battarel	<christophe.battarel@altairis.fr>
 * Copyright (C) 2012       Cédric Salvador     <csalvador@gpcsolutions.fr>
 * Copyright (C) 2014		Florian Henry		<florian.henry@open-concept.pro>
 * Copyright (C) 2014       Raphaël Doursenaud  <rdoursenaud@gpcsolutions.fr>
 * Copyright (C) 2015-2016	Marcos García		<marcosgdf@gmail.com>
 * Copyright (C) 2018-2019  Frédéric France         <frederic.france@netlogic.fr>
 * Copyright (C) 2018		Ferran Marcet		<fmarcet@2byte.es>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 *
 * Need to have following variables defined:
 * $object (invoice, order, ...)
 * $conf
 * $langs
 * $forceall (0 by default, 1 for supplier invoices/orders)
 */


print '<tr class="liste_titre nodrag nodrop">';
if (!empty($conf->global->MAIN_VIEW_LINE_NUMBER)) {
		print '<td class="linecolnum center"></td>';
}

$sel='<table><tr><td><img width="18" class="imcheck" id="ck@@" raw="@@" style="opacity:0.2;" src="quality/img/check.png"/></td> <td><img width="18" class="imcan" id="ca@@" raw="@@" style="opacity:0.2;" src="quality/img/cancel.png"/></td><tr></table>';

$coldisplay++;
$sal = str_replace("@@", "appearance", $sel);
print '<td valign="middle" align="center" > - ';
print '</td>';

$coldisplay++;
$sal = str_replace("@@", "fill", $sel);
print '<td width="400"  align="center" class="bordertop nobottom">';
print '<input id="titulo" name="titulo" class="minwidth300 maxwidth400onsmartphone" maxlength="255" value="">';
print '</td>';

$coldisplay++;
print '<td align="center" class="bordertop nobottom">';
print '<select class="flat minwidth100 maxwidthonsmartphone " name = "status" tabindex="-1" aria-hidden="true"><option value="1" >'.$langs->trans('Active').'</option><option value="2" >'.$langs->trans('Inactive').'</option></select>';
print '</td>';


$coldisplay++;
print '<td align="center" class="bordertop nobottom">';
if ($conf->categorie->enabled) {
			// Categories
			$cate_arbo = $form->select_all_categories(Categorie::TYPE_PRODUCT, '', 'parent', 64, 0, 1);
			print img_picto('', 'category').$form->multiselectarray('categories', $cate_arbo, array(), '', 0, 'quatrevingtpercent widthcentpercentminusx', 0, 0);
			
		}
print '</td>';

print '</tr>';

print '<tr>';
//$coldisplay += $colspan;
print '<td class="bordertop nobottom linecoledit center valignmiddle" colspan="17">';
print '<input type="button" class="button" value="'.$langs->trans('Add').'" name="addline" id="addline"></br></br>';

print '</td>';
print '</tr>';


if (is_object($objectline)) {
	print $objectline->showOptionals($extrafields, 'edit', array('style'=>$bcnd[$var], 'colspan'=>$coldisplay), '', '', 1);
}
?>

<!-- END PHP TEMPLATE objectline_create.tpl.php -->
