# CONTROL DE CALIDAD PARA PRODUCCION Y PROYECTOS [DOLIBARR ERP CRM]

## Características


Descripción del módulo en español...


Maneja Órdenes de Fabricación (MRP) o Proyectos en Dolibarr? Configure sus propias listas de control de calidad con la ayuda de esta funcionalidad, genere plantillas personalizadas que podrá agregar a las Órdenes de fabrización y/o Proyectos y llevar el control de los aspectos que marcan la calidad de sus trabajos y productos, exporte los registros a Excel y analice sus resultados, manetenga el control de sus procesos.


## Features
Do you manage Manufacturing Orders (MRP) or Projects in Dolibarr? Configure your own quality control lists with the help of this functionality, generate personalized templates that you can add to the Manufacturing Orders and/or Projects and keep track of the aspects that mark the quality of your work and products, export the records to Excel and analyze your results, maintain control of your processes.

<!--
This module contains also a sample configuration for Transifex, under the hidden directory [.tx](.tx), so it is possible to manage translation using this service.

For more informations, see the [translator's documentation](https://wiki.dolibarr.org/index.php/Translator_documentation).

There is a [Transifex project](https://transifex.com/projects/p/dolibarr-module-template) for this module.
-->

<!--

## Installation

### From the ZIP file and GUI interface

- If you get the module in a zip file (like when downloading it from the market place [Dolistore](https://www.dolistore.com)), go into
menu ```Home - Setup - Modules - Deploy external module``` and upload the zip file.

Note: If this screen tell you there is no custom directory, check your setup is correct:

- In your Dolibarr installation directory, edit the ```htdocs/conf/conf.php``` file and check that following lines are not commented:

    ```php
    //$dolibarr_main_url_root_alt ...
    //$dolibarr_main_document_root_alt ...
    ```

- Uncomment them if necessary (delete the leading ```//```) and assign a sensible value according to your Dolibarr installation

    For example :

    - UNIX:
        ```php
        $dolibarr_main_url_root_alt = '/custom';
        $dolibarr_main_document_root_alt = '/var/www/Dolibarr/htdocs/custom';
        ```

    - Windows:
        ```php
        $dolibarr_main_url_root_alt = '/custom';
        $dolibarr_main_document_root_alt = 'C:/My Web Sites/Dolibarr/htdocs/custom';
        ```

### From a GIT repository

- Clone the repository in ```$dolibarr_main_document_root_alt/monitorcomandas```

```sh
cd ....../custom
git clone git@github.com:gitlogin/monitorcomandas.git monitorcomandas
```

### <a name="final_steps"></a>Final steps

From your browser:

  - Log into Dolibarr as a super-administrator
  - Go to "Setup" -> "Modules"
  - You should now be able to find and enable the module

-->

## Licencia (License)

GPLv3.

## Contacto (contact)

Español : Necesita una mejora a este módulo? o ayuda para adecuar su Dolibarr? contáctenos

English : Need an upgrade to this module? or help to adjust your Dolibarr? Contact Us

Italiano: Hai bisogno di un aggiornamento a questo modulo? o aiutare a regolare il tuo Dolibarr? Contattaci

<i class="fa fa-envelope-o"></i> <a href="mailto:codlines256@gmail.com">CodLines</a>
<br/>

<i class="fa fa-facebook-official"></i></i> <a target="_blank" href="https://www.facebook.com/codlines">Facebook CodLines</a>
