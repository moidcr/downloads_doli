<?php
/* Copyright (C) 2017  Laurent Destailleur <eldy@users.sourceforge.net>
 * Copyright (C) 2020  Lenin Rivas		   <lenin@leninrivas.com>
 * Copyright (C) ---Put here your own copyright and developer email---
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <http://www.gnu.org/licenses/>.
 */
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use PhpOffice\PhpSpreadsheet\Cell\Coordinate;

if($action == "addlinequality_v2" && !empty($permissiontoaddquality))
{
	$sql = "SELECT p.field, p.title, p.type ";
	$sql .= " FROM of_quality_cust_cpy as p";
	$sql .= " WHERE p.fk_muprof = ".$id;
	$sql .= " AND p.unikey = '".$tabq."'";
	$sql .= " AND p.origin_type = '".$object->element."'";
	$sql .= " ORDER BY p.order";
	
	//echo $sql;
	$fields = array();
	$resql = $db->query($sql);
	
	if ($resql)
	{
		$num = $db->num_rows($resql);		
		if ($num > 0)
		{
							
			$i = 0;
			while ($i < $num ) {
				$objt = $db->fetch_object($resql);
				if(isset($objt->field))
				{
					$fields[] = $objt;
				}
				$i++;
			}
		}
	}
	
	$f = 0;
	
	$sqlu1 = "";
	$sqlu2 = "";
	foreach($fields as $key => $field)
	{
		if($f > 0)
		{
			$sqlu1.= ", ";
			$sqlu2.= ", ";
		}

		if($field->type=="ck")
		{
			$sqlu1.= " $field->field ";
			$sqlu2.= "'".GETPOST($field->field, 'alpha')."'";
		}
		
		if($field->type=="nm")
		{
			$sqlu1.= " $field->field ";
			$sqlu2.= "'".GETPOST($field->field, 'int')."'";
		}
		
		if($field->type=="tx")
		{
			$sqlu1.= " $field->field ";
			$sqlu2.= "'".GETPOST($field->field, 'alpha')."'";
		}
		
		if($field->type=="nt")
		{
			$sqlu1.= " $field->field ";
			$sqlu2.= "'".addslashes(GETPOST($field->field, 'restricthtml'))."'";
		}
		
		$f++;
	}
	
	$sqlu = "INSERT INTO of_quality_cust (".$sqlu1.", fk_muprof, origin_type, template, date_creation, fk_user_creat) values (".$sqlu2.", '".$id."', '".$object->element."', '".$tabq."',  NOW(), '".$user->id."' )";
	//echo $sqlu;
	//exit;					
	$resqli = $db->query($sqlu);
}

if($action == "updatequality_v2" && !empty($permissiontoeditquality))
{
	$sql = "SELECT p.field, p.title, p.type ";
	$sql .= " FROM of_quality_cust_cpy as p";
	$sql .= " WHERE p.fk_muprof = ".$id;
	$sql .= " AND p.unikey = '".$tabq."'";
	$sql .= " AND p.origin_type = '".$object->element."'";
	$sql .= " ORDER BY p.order";
	
	//echo $sql;
	$fields = array();
	$resql = $db->query($sql);
	
	if ($resql)
	{
		$num = $db->num_rows($resql);		
		if ($num > 0)
		{
							
			$i = 0;
			while ($i < $num ) {
				$objt = $db->fetch_object($resql);
				if(isset($objt->field))
				{
					$fields[] = $objt;
				}
				$i++;
			}
		}
	}
	
	$f = 0;
	
	$sqlu1 = "";
	foreach($fields as $key => $field)
	{
		if($f > 0)
		{
			$sqlu1.= ", ";
		}

		if($field->type=="ck")
		{
			$sqlu1.= " $field->field = '".GETPOST($field->field, 'alpha')."'";

		}
		
		if($field->type=="nm")
		{
			$sqlu1.= " $field->field = '".GETPOST($field->field, 'int')."'";
		}
		
		if($field->type=="tx")
		{
			$sqlu1.= " $field->field = '".GETPOST($field->field, 'alpha')."'";

		}
		
		if($field->type=="nt")
		{
			$sqlu1.= " $field->field = '".addslashes(GETPOST($field->field, 'restricthtml'))."'";
		}
		
		$f++;
	}
	
	$sqlu = "UPDATE of_quality_cust SET ".$sqlu1.", fk_user_modif = '".$user->id."' WHERE fk_muprof = '".$id."'  AND origin_type = '".$object->element."' AND template = '".$tabq."' AND rowid = '".$lineid."'";
	//echo $sqlu;
	//exit;					
	$resqli = $db->query($sqlu);
}

// Remove a line
if ($action == 'confirm_deletelinev2' && $confirm == 'yes' && !empty($permissiontoeditquality))
{
	
	$Resp["Res"] = "Error";
	$sql = "DELETE FROM of_quality_cust";
	$sql .= " where rowid = '".$lineid."'";
	
	$resql = $db->query($sql);
	if($resql)
	{
		// Define output language
		$outputlangs = $langs;

		setEventMessages($langs->trans('RecordDeleted'), null, 'mesgs');
		header('Location: '.$_SERVER["PHP_SELF"].'?id='.$id.'&tabq='.$tabq);
		exit;
	} else {
		//echo "holl";
		setEventMessages($db->error, $db->errors, 'errors');
	}
}

// Remove a line
if ($action == 'confirm_deletetemp' && $confirm == 'yes' && !empty($user->rights->ofquality->myobject->add_temp_q))
{
	
	$Resp["Res"] = "Error";
	$sql = "DELETE FROM of_quality_cust";
	$sql .= " where fk_muprof = '".$id."' AND template = '".$tabq."' AND origin_type = '".$object->element."'";
	
	$resql = $db->query($sql);
	
	$sql = "DELETE FROM of_quality_cust_cpy";
	$sql .= " where fk_muprof = '".$id."' AND unikey = '".$tabq."' AND origin_type = '".$object->element."'";
	
	$resql = $db->query($sql);
	
	if($resql)
	{
		// Define output language
		$outputlangs = $langs;

		setEventMessages($langs->trans('RecordDeleted'), null, 'mesgs');
		header('Location: '.$_SERVER["PHP_SELF"].'?id='.$id);
		exit;
	} else {
		//echo "holl";
		setEventMessages($db->error, $db->errors, 'errors');
	}
}

if($action == "exportxls")
{
$temp_name = "";
$sql = "SELECT p.field, p.title, p.type, p.fk_temp_name ";
$sql .= " FROM of_quality_cust_cpy as p";
$sql .= " WHERE p.fk_muprof = ".$id;
$sql .= " AND p.unikey = '".$tabq."'";
$sql .= " ORDER BY CAST(p.order AS UNSIGNED);";

//echo $sql;
$fieldsx = array();
$resql = $db->query($sql);
if ($resql)
{
	$numx = $db->num_rows($resql);		
	if ($numx > 0)
	{
						
		$i = 0;
		while ($i < $numx ) {
			$objt = $db->fetch_object($resql);
			if(isset($objt->field))
			{
				$temp_name = $objt->fk_temp_name;
				$fieldsx[] = $objt;
			}
			$i++;
		}
	}
}
	
		dol_include_once('/custom/ofquality/includes/phpoffice/autoloader.php');
		dol_include_once('/custom/ofquality/includes/Psr/autoloader.php');
		dol_include_once('/custom/ofquality/includes/phpoffice/phpspreadsheet/src/PhpSpreadsheet/Spreadsheet.php');
	
	
$mySpreadsheet = new Spreadsheet();

// delete the default active sheet
$mySpreadsheet->removeSheetByIndex(0);

// Create "Sheet 1" tab as the first worksheet.
// https://phpspreadsheet.readthedocs.io/en/latest/topics/worksheets/adding-a-new-worksheet
$worksheet1 = new \PhpOffice\PhpSpreadsheet\Worksheet\Worksheet($mySpreadsheet, $temp_name);
$mySpreadsheet->addSheet($worksheet1, 0);

// Create "Sheet 2" tab as the second worksheet.
//$worksheet2 = new \PhpOffice\PhpSpreadsheet\Worksheet\Worksheet($mySpreadsheet, "Sheet 2");
//$mySpreadsheet->addSheet($worksheet2, 1);




$f = 0;
$query = "select rowid, ";
foreach($fieldsx as $key => $field)
{
	$query .= $field->field;
	
	if($field->type=="ck")
	{
		
	}
	$f++;
}


$sql = "SELECT p.* ";
$sql .= " FROM of_quality_cust as p";
$sql .= " WHERE p.fk_muprof = ".$id;
$sql .= " AND p.template = '".$tabq."'";
$sql .= " AND p.origin_type = '".$object->element."'";
$sql .= " ORDER BY p.rowid";

//echo $sql;
$valuesx = array();
$resql = $db->query($sql);
if ($resql)
{
	$num = $db->num_rows($resql);		
	if ($num > 0)
	{
						
		$i = 0;
		while ($i < $num ) {
			$objt = $db->fetch_object($resql);
			if(isset($objt->fk_muprof))
			{
				$valuesx[] = $objt;
			}
			$i++;
		}
	}
}


// sheet 1 contains the birthdays of famous people.
$sheet1Data = [];
//print_r($fieldsx);
//exit;
$titles = [];
foreach($fieldsx as $key => $field){
	$titles[] = $field->title;
}
$titles[] = $langs->trans('Date');
$titles[] = $langs->trans('Signature');
$sheet1Data[] = $titles;

foreach($valuesx as $line)
{
	$valuesx_ = [] ;
	foreach($fieldsx as $key => $field)
	{
		if($field->type=="ck")
		{
			if($line->{$field->field} == "YES")
				$valuesx_[] = "OK";
			else
				$valuesx_[] = "NO";
		}
		elseif($field->type=="nm") {
			$valuesx_[] = $line->{$field->field};
		}
		elseif($field->type=="tx")
		{
			$valuesx_[] = $line->{$field->field};
		}
		elseif($field->type=="nt")
		{
			$valuesx_[] = $line->{$field->field};
		}
	}
	$valuesx_[] = dol_print_date($line->date_creation,'dayrfc')." ".dol_print_date($line->date_creation,'hour');
	$userstaticw = new User($db);
	$userstaticw->fetch($line->fk_user_creat);
	//$line->fk_user_creat = $userstaticw->getNomUrl(1, '', 0, 0, 24, 0, 'login');
	
	$valuesx_[] = $userstaticw->firstname." ".$userstaticw->lastname;
	$sheet1Data[] = $valuesx_;
}
// Sheet 2 contains list of ferrari cars and when they were manufactured.
/*$sheet2Data = [
    ["Model", "Production Year Start", "Production Year End"],
    ["308 GTB",  1975, 1985],
    ["360 Spider",  1999, 2004],
    ["488 GTB",  2015, 2020],
];*/


$worksheet1->fromArray($sheet1Data);
//$worksheet2->fromArray($sheet2Data);


// Change the widths of the columns to be appropriately large for the content in them.
// https://stackoverflow.com/questions/62203260/php-spreadsheet-cant-find-the-function-to-auto-size-column-width
//$worksheets = [$worksheet1, $worksheet2];
$worksheets = [$worksheet1];

foreach ($worksheets as $worksheet)
{
    foreach ($worksheet->getColumnIterator() as $column)
    {
        $worksheet->getColumnDimension($column->getColumnIndex())->setAutoSize(true);
    }
}
$file = $langs->trans('ofquality').' '.$object->ref.'.xlsx';
// Save to file.
$writer = new PhpOffice\PhpSpreadsheet\Writer\Xlsx($mySpreadsheet);
$writer->save($file);

$name = basename($file);

header('Pragma: public');
header('Expires: 0');
header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
header('Cache-Control: private', false);
header('Content-Transfer-Encoding: binary');
header('Content-Disposition: inline; filename="'.$name.'";');
header('Content-Type:  application/octet-stream');
header('Content-Length: ' . filesize($file));

//  Buffering file
$chunkSize = 8 *(1024 * 1024);
$handle = fopen($file, 'rb');
while (!feof($handle))
{
     $buffer = fread($handle, $chunkSize);
     echo $buffer;
     ob_flush();
     flush();
}
fclose($handle);
unlink($file);

}
