<?php
/* Copyright (C) 2019 Laurent Destailleur  <eldy@users.sourceforge.net>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <http://www.gnu.org/licenses/>.
 */

/**
 *   	\file       muprof_quality.php
 *		\ingroup    multiprodof
 *		\brief      Page to show quality_of_the_piece of a MUPROF
 */

// Load Dolibarr environment
$res = 0;
// Try main.inc.php into web root known defined into CONTEXT_DOCUMENT_ROOT (not always defined)
if (!$res && !empty($_SERVER["CONTEXT_DOCUMENT_ROOT"])) {
	$res = @include $_SERVER["CONTEXT_DOCUMENT_ROOT"]."/main.inc.php";
}
// Try main.inc.php into web root detected using web root calculated from SCRIPT_FILENAME
$tmp = empty($_SERVER['SCRIPT_FILENAME']) ? '' : $_SERVER['SCRIPT_FILENAME']; $tmp2 = realpath(__FILE__); $i = strlen($tmp) - 1; $j = strlen($tmp2) - 1;
while ($i > 0 && $j > 0 && isset($tmp[$i]) && isset($tmp2[$j]) && $tmp[$i] == $tmp2[$j]) {
	$i--; $j--;
}
if (!$res && $i > 0 && file_exists(substr($tmp, 0, ($i + 1))."/main.inc.php")) {
	$res = @include substr($tmp, 0, ($i + 1))."/main.inc.php";
}
if (!$res && $i > 0 && file_exists(dirname(substr($tmp, 0, ($i + 1)))."/main.inc.php")) {
	$res = @include dirname(substr($tmp, 0, ($i + 1)))."/main.inc.php";
}
// Try main.inc.php using relative path
if (!$res && file_exists("../main.inc.php")) {
	$res = @include "../main.inc.php";
}
if (!$res && file_exists("../../main.inc.php")) {
	$res = @include "../../main.inc.php";
}
if (!$res && file_exists("../../../main.inc.php")) {
	$res = @include "../../../main.inc.php";
}
if (!$res) {
	die("Include of main fails");
}


require_once DOL_DOCUMENT_ROOT.'/projet/class/project.class.php';
require_once DOL_DOCUMENT_ROOT.'/core/lib/company.lib.php';
require_once DOL_DOCUMENT_ROOT.'/core/lib/files.lib.php';
require_once DOL_DOCUMENT_ROOT.'/core/lib/images.lib.php';
require_once DOL_DOCUMENT_ROOT.'/core/class/html.formfile.class.php';
require_once DOL_DOCUMENT_ROOT.'/core/class/html.formprojet.class.php';
dol_include_once('/mrp/class/mo.class.php');
dol_include_once('/mrp/lib/mrp_mo.lib.php');

// Load translation files required by the page
$langs->loadLangs(array("ofquality@ofquality", "mrp", "stocks", "other"));

// Get parameters
$id = GETPOST('id', 'int');
$ref        = GETPOST('ref', 'alpha');
$action = GETPOST('action', 'aZ09');
$tabq = GETPOST('tabq', 'alpha') ? GETPOST('tabq', 'alpha') : 'def' ;
$confirm    = GETPOST('confirm', 'alpha');
$cancel     = GETPOST('cancel', 'aZ09');
$contextpage = GETPOST('contextpage', 'aZ') ?GETPOST('contextpage', 'aZ') : 'muprofquality'; // To manage different context of search
$backtopage = GETPOST('backtopage', 'alpha');
$lineid   = GETPOST('lineid', 'int');

// Initialize technical objects
$object = new Mo($db);
$extrafields = new ExtraFields($db);
$diroutputmassaction = $conf->mrp->dir_output.'/temp/massgeneration/'.$user->id;
$hookmanager->initHooks(array('moofquality', 'globalcard')); // Note that conf->hooks_modules contains array

$object->fetch($id); // Reload to get new records
// Fetch optionals attributes and labels
$extrafields->fetch_name_optionals_label($object->table_element);

//echo "<pre>";
//print_r($object);
$permissiontoaddquality = $user->rights->ofquality->myobject->add_qual_reg;
$permissiontoeditquality = $user->rights->ofquality->myobject->edit_qual_reg;

function numero_aleatorio ($ninicial, $nfinal) {
    $numero = rand($ninicial, $nfinal);

    return $numero;
}

function genera_codigo($longitud) 
{
    $caracteres = array("0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z");
    $codigo = '';

    for ($i = 1; $i <= $longitud; $i++) {
        $codigo .= $caracteres[numero_aleatorio(0, 35)];
    }

    return $codigo;
}

if (empty($reshook))
{
	$error = 0;

	$backurlforlist = dol_buildpath('/mrp/mo_list.php', 1);

	if (empty($backtopage) || ($cancel && empty($id))) {
		//var_dump($backurlforlist);exit;
		if (empty($id) && (($action != 'add' && $action != 'create') || $cancel)) $backtopage = $backurlforlist;
		else $backtopage = DOL_URL_ROOT.'/mrp/mo_card.php.php?id='.($id > 0 ? $id : '__ID__');
	}
	$triggermodname = 'MULTIPRODOF_MUPROF_MODIFY'; // Name of trigger action code to execute when we modify record
	
	if($action == 'update')
	{
		//Only viewa and edit fields for quality
		$object->fields['temper']['visible']=1;
		$object->fields['water_circulates']['visible']=1;
		$object->fields['rack_in_temp']['visible']=1;
		$object->fields['ejector_safety']['visible']=1;
		$object->fields['mold_cleaning']['visible']=1;
		$object->fields['dater']['visible']=1;
		$object->fields['notes']['visible']=1;
		
		
		if($object->fk_user_quality=="")
		{
			$object->fields['fk_user_quality']['visible']=1;
			$object->fk_user_quality = $user->id;
		}
		if($object->signature=="")
		{
			$object->fields['signature']['visible']=1;
			$now = dol_now();
			$object->signature = $object->db->idate($now);
		}
		// Actions cancel, add, update, update_extras, confirm_validate, confirm_delete, confirm_deleteline, confirm_clone, confirm_close, confirm_setdraft, confirm_reopen
		dol_include_once('/core/actions_addupdatedelete.inc.php');
	}
	elseif($action=="add_temp")
	{
		$Resp["Res"] = "ERROR";
		$tmp = GETPOST('tmp', 'int');
		$sql = "SELECT p.rowid, p.title";
		$sql .= " FROM of_quality_tmp_c as p";
		$sql .= " WHERE p.rowid = ".$tmp;
	
		$resql = $db->query($sql);
		if ($resql) {
			$num = $db->num_rows($resql);
			
			$wfobj = $db->fetch_object($resql);
			$i = 0;
			if(isset($wfobj->rowid))
			{
				$cod = genera_codigo(10);
				$sql = "SELECT p.rowid, p.type, p.title, p.order";
				$sql .= " FROM of_quality_tmp_c_details as p";
				$sql .= " WHERE p.fk_temp = ".$tmp;
				$sql .= " ORDER BY p.order";
				$fields = array();
				$resql = $db->query($sql);
				if ($resql) {
					$num = $db->num_rows($resql);
					
					if ($num > 0) {
						
						$ck = $nm = $tx = $nt = 1;
						while ($i < $num ) {
							$objl = $db->fetch_object($resql);
							
							$sql = 'INSERT INTO of_quality_cust_cpy';
							$sql .= ' (fk_muprof, origin_type, fk_temp, fk_temp_name, fk_id, title, type, `order`, unikey, field';
							$sql .= ')';
							$sql .= " VALUES ('".$id."', ";
							$sql .= " '".$object->element."', ";
							$sql .= " '".$tmp."', ";
							$sql .= " '".$wfobj->title."', ";
							$sql .= " '".$objl->rowid."', ";
							$sql .= " '".$objl->title."', ";
							$sql .= " '".$objl->type."', ";
							$sql .= " '".$objl->order."', ";
							$sql .= " '".$cod."', ";
							$val = $objl->type.${$objl->type};
							$sql .= " '".$val."' ";
							${$objl->type}++;
							
							
							$sql .= ')';
						
							$resqli = $db->query($sql);
							
							
							
							$i++;
						}
					}
				}
			}
			
			if($i>0)
			{
				setEventMessages($langs->trans('success_add_tmp'), null, 'mesgs');
				$Resp["Res"] = "OK";
				$Resp["temp"] = $cod;
			}
			else
			{
				setEventMessages($langs->trans('error_add_tmp'), null, 'errors');
			}
	
		}
		
		echo json_encode($Resp);
		exit;
	}
	else {
		// Actions cancel, add, update, delete or clone quality object
		include('class/actions_quality.class.php');
	}
	

	// Actions to send emails
	$triggersendname = 'MUPROF_SENTBYMAIL';
	$autocopy = 'MAIN_MAIL_AUTOCOPY_MUPROF_TO';
	$trackid = 'muprof'.$object->id;
	// Action to move up and down lines of object
	//include DOL_DOCUMENT_ROOT.'/core/actions_lineupdown.inc.php';	// Must be include, not include_once

	if ($action == 'set_thirdparty' && $permissiontoadd)
	{
		$object->setValueFrom('fk_soc', GETPOST('fk_soc', 'int'), '', '', 'date', '', $user, 'MUPROF_MODIFY');
	}
	if ($action == 'classin' && $permissiontoadd)
	{
		$object->setProject(GETPOST('projectid', 'int'));
	}

	if ($action == 'confirm_reopen') {
		$result = $object->setStatut($object::STATUS_INPROGRESS, 0, '', 'MULTIPRODOF_REOPEN');
	}
}



// Load object
dol_include_once('/core/actions_fetchobject.inc.php'); // Must be include, not include_once  // Must be include, not include_once. Include fetch and fetch_thirdparty but not fetch_optionals

if ($id > 0 || !empty($ref)) {
	$upload_dir = $conf->mrp->multidir_output[$object->entity ? $object->entity : $conf->entity]."/".get_exdir(0, 0, 0, 1, $object);
}

// Security check - Protection if external user
//if ($user->socid > 0) accessforbidden();
//if ($user->socid > 0) $socid = $user->socid;
$isdraft = (($object->status == $object::STATUS_DRAFT) ? 1 : 0);
$result = restrictedArea($user, 'mrp', $object->id, 'mrp_mo', '', 'fk_soc', 'rowid', $isdraft);


/*
 * Actions
 */

dol_include_once('/core/actions_linkedfiles.inc.php');


/*
 * View
 */

$form = new Form($db);
$formproject = new FormProjets($db);

$title = $langs->trans("Mo").' - '.$langs->trans("OfQuality");
$help_url = '';
//$help_url='EN:Module_Third_Parties|FR:Module_Tiers|ES:Empresas';
llxHeader('', $title, $help_url);

if ($object->id) {
	/*
	 * Show tabs
	 */
	$head = moPrepareHead($object);

	print dol_get_fiche_head($head, 'ofquality', $langs->trans("ManufacturingOrder"), -1, $object->picto);

	// Build file list
	$filearray = dol_dir_list($upload_dir, "ofquality", 0, '', '(\.meta|_preview.*\.png)$', $sortfield, (strtolower($sortorder) == 'desc' ?SORT_DESC:SORT_ASC), 1);
	$totalsize = 0;
	foreach ($filearray as $key => $file) {
		$totalsize += $file['size'];
	}

	// Object card
	// ------------------------------------------------------------
	$linkback = '<a href="'.dol_buildpath('/mrp/mo_list.php', 1).'?restore_lastsearch_values=1'.(!empty($socid) ? '&socid='.$socid : '').'">'.$langs->trans("BackToList").'</a>';

	$morehtmlref = '<div class="refidno">';
	// Ref customer
	//$morehtmlref.=$form->editfieldkey("RefCustomer", 'ref_client', $object->ref_client, $object, 0, 'string', '', 0, 1);
	//$morehtmlref.=$form->editfieldval("RefCustomer", 'ref_client', $object->ref_client, $object, 0, 'string', '', null, null, '', 1);
	// Thirdparty
	$morehtmlref .= $langs->trans('ThirdParty').' : '.(is_object($object->thirdparty) ? $object->thirdparty->getNomUrl(1) : '');
	// Project
	if (!empty($conf->projet->enabled)) {
		$langs->load("projects");
		$morehtmlref .= '<br>'.$langs->trans('Project').' ';
		if ($permissiontoadd) {
			if ($action != 'classify') {
				$morehtmlref .= '<a class="editfielda" href="'.$_SERVER['PHP_SELF'].'?action=classify&amp;id='.$object->id.'">'.img_edit($langs->transnoentitiesnoconv('SetProject')).'</a> : ';
			}
			if ($action == 'classify') {
				//$morehtmlref.=$form->form_project($_SERVER['PHP_SELF'] . '?id=' . $object->id, $object->fk_soc, $object->fk_project, 'projectid', 0, 0, 1, 1);
				$morehtmlref .= '<form method="post" action="'.$_SERVER['PHP_SELF'].'?id='.$object->id.'">';
				$morehtmlref .= '<input type="hidden" name="action" value="classin">';
				$morehtmlref .= '<input type="hidden" name="token" value="'.newToken().'">';
				$morehtmlref .= $formproject->select_projects($object->fk_soc, $object->fk_project, 'projectid', 0, 0, 1, 0, 1, 0, 0, '', 1);
				$morehtmlref .= '<input type="submit" class="button valignmiddle" value="'.$langs->trans("Modify").'">';
				$morehtmlref .= '</form>';
			} else {
				$morehtmlref .= $form->form_project($_SERVER['PHP_SELF'].'?id='.$object->id, $object->fk_soc, $object->fk_project, 'none', 0, 0, 0, 1);
			}
		} else {
			if (!empty($object->fk_project)) {
				$proj = new Project($db);
				$proj->fetch($object->fk_project);
				$morehtmlref .= ': '.$proj->getNomUrl();
			} else {
				$morehtmlref .= '';
			}
		}
	}
	$morehtmlref .= '</div>';

	dol_banner_tab($object, 'ref', $linkback, 1, 'ref', 'ref', $morehtmlref);

// Part to show record
if ($object->id > 0 && (empty($action) || ($action != 'editquality')))
{
	$res = $object->fetch_thirdparty();
	$res = $object->fetch_optionals();

	//$head = muprofPrepareHead($object);

	//print dol_get_fiche_head($head, 'quality', $langs->trans("ManufacturingOrder"), -1, $object->picto);

	$formconfirm = '';

	// Confirmation to delete
	if ($action == 'delete')
	{
		$formconfirm = $form->formconfirm($_SERVER["PHP_SELF"].'?id='.$object->id, $langs->trans('DeleteMuPrOf'), $langs->trans('ConfirmDeleteMuPrOf'), 'confirm_delete', '', 0, 1);
	}
	// Confirmation to delete line
	if ($action == 'deleteline')
	{
		$formconfirm = $form->formconfirm($_SERVER["PHP_SELF"].'?id='.$object->id.'&lineid='.$lineid, $langs->trans('DeleteLine'), $langs->trans('ConfirmDeleteLine'), 'confirm_deleteline', '', 0, 1);
	}
	// Confirmation to delete line v2
	if ($action == 'deletelinev2')
	{
		$formconfirm = $form->formconfirm($_SERVER["PHP_SELF"].'?id='.$object->id.'&tabq='.$tabq.'&lineid='.$lineid, $langs->trans('DeleteLine'), $langs->trans('ConfirmDeleteLine'), 'confirm_deletelinev2', '', 0, 1);
	}
	
	// Confirmation to delete template
	if ($action == 'deletetemp')
	{
		$formconfirm = $form->formconfirm($_SERVER["PHP_SELF"].'?id='.$object->id.'&tabq='.$tabq, $langs->trans('Delete_temp'), $langs->trans('Confirm_Delete_temp'), 'confirm_deletetemp', '', 0, 1);
	}
	
	// Clone confirmation
	if ($action == 'clone') {
		// Create an array for form
		$formquestion = array();
		$formconfirm = $form->formconfirm($_SERVER["PHP_SELF"].'?id='.$object->id, $langs->trans('ToClone'), $langs->trans('ConfirmCloneMuPrOf', $object->ref), 'confirm_clone', $formquestion, 'yes', 1);
	}

	// Confirmation of action xxxx
	/*if ($action == 'xxx')
	{
		$formquestion = array();

		$formconfirm = $form->formconfirm($_SERVER["PHP_SELF"].'?id='.$object->id, $langs->trans('XXX'), $text, 'confirm_xxx', $formquestion, 0, 1, 220);
	}*/

	// Call Hook formConfirm
	$parameters = array('formConfirm' => $formconfirm, 'lineid' => $lineid);
	$reshook = $hookmanager->executeHooks('formConfirm', $parameters, $object, $action); // Note that $action and $object may have been modified by hook
	if (empty($reshook)) $formconfirm .= $hookmanager->resPrint;
	elseif ($reshook > 0) $formconfirm = $hookmanager->resPrint;

	// Print form confirm
	print $formconfirm;


$sql = "SELECT p.rowid, p.title, p.status, p.modified_date";
$sql .= " FROM of_quality_tmp_c as p";
$sql .= " WHERE p.status = 1";

$resql = $db->query($sql);
$templatese = array();
if ($resql) {
	$total = 0;
	$num = $db->num_rows($resql);
	if ($num > 0) {
		$i = 0;

		while ($i < $num) {
			$obj = $db->fetch_object($resql);
			$templatese[$obj->rowid] = $obj->title;
			$i++;
		}
	}
}


//$Quality = new Quality($db);
//$Quality->id = $object->id;
//$Quality->fetchLines();

$sql = "SELECT p.unikey, p.fk_temp_name";
$sql .= " FROM of_quality_cust_cpy as p";
$sql .= " WHERE p.fk_muprof = ".$id;
$sql .= " AND p.origin_type = '".$object->element."'";
$sql .= " GROUP BY p.unikey ";
$sql .= " ORDER BY p.rowid";

//echo $sql;
$templates = array();
$resql = $db->query($sql);
if ($resql) {
	$num = $db->num_rows($resql);		
	if ($num > 0)
	{
						
		$i = 0;
		while ($i < $num ) {
			$objt = $db->fetch_object($resql);
			if(isset($objt->unikey))
			{
				if($i==0 && $tabq == "def")
					$tabq = $objt->unikey;
				$templates[$objt->unikey] = $objt->fk_temp_name;
			}
			$i++;
		}
	}
}

if($user->rights->ofquality->myobject->add_temp_q)
{
	print '<table width="100%" class="border">';
	
	
	
	print '<tr>';
	print '<td   width="20%">'.$langs->trans('Quality_temp').': </td>';
	print '<td width="20%"><select class="flat minwidth100 maxwidthonsmartphone select2" id="template" name = "template" tabindex="-1" aria-hidden="true">
	<option value=""  >'.$langs->trans('select_quality').'</option>';
	
	foreach($templatese as $key => $tit)
	{
		print '<option value="'.$key.'" >'.$tit.'</option>';
	}
	
	print '</select>';
			
	print '</td>';
	print '<td width="10%" class="titlefieldcreate"><span id="TypeName" class="fieldrequired"><span class="paginationafterarrows"><a class="btnTitle btnTitlePlus" href="javascript:AddTemp()" title="'.$langs->trans("Add_temp").'"><span class="fa fa-plus-circle valignmiddle btnTitle-icon"></span></a></span></span></td>';
	
	if($tabq != 'def')
	{
		print '<td width="1%" align="right" class="titlefieldcreate"><span id="TypeName" class="fieldrequired"><span class="paginationafterarrows"><a class="btnTitle btnTitlePlus" href="'.$_SERVER["PHP_SELF"].'?id='.$object->id.'&amp;action=exportxls&tabq='.$tabq.'" title="'.$langs->trans("Export_excel").'"><span class="fa fa-file-excel-o valignmiddle btnTitle-icon"></span></a></span></span></td>';
		
	print '<td width="1%" align="right" class="titlefieldcreate"><span id="TypeName" class="fieldrequired"><span class="paginationafterarrows"><a class="btnTitle btnTitlePlus" href="'.$_SERVER["PHP_SELF"].'?id='.$object->id.'&amp;action=deletetemp&tabq='.$tabq.'" title="'.$langs->trans("Delete_temp").'"><span style="color: red;" class="fa fa-minus-circle valignmiddle btnTitle-icon"></span></a></span></span></td>';
	}
	print '</tr>';
				
	print '</table>';
}

if(count($templates) > 0)
{

print '<div class="tabs" data-role="controlgroup" data-type="horizontal">';
	

	//echo $tabq."====";
	foreach($templates as $ki => $template){
		print '<div class="inline-block tabsElem '.($tabq == $ki ? 'tabsElemActive' : '').'"><!-- id tab = tmp'.$ki.' -->';
		print '<a id="tmp'.$ki.'" class="'.($tabq == $ki ? 'tabactive' : 'tabunactive').' tab inline-block" href="'.$_SERVER['PHP_SELF'].'?id='.$id.'&tabq='.$ki.'">'.$template.'</a>';
		print '</div>';
	}
print '</div>';


} ?>

<div class="tabBar">

<?php

	

		include 'of_quality_inc.php';
}

?>
</div>
<script>
	function AddTemp()
	{
		var tmp = $("#template").val();
		
		if(tmp!="")
		{
			$.ajax({
				type: "POST",
				url: "<?php echo $_SERVER['PHP_SELF'].'?id='.$id; ?>",
				data: { token: '<?php echo currentToken(); ?>', action: "add_temp", tmp: tmp },
				success: function(data, status, xhr) {
					var obj = JSON.parse(data); //if the dataType is not specified as json uncomment this
					if(obj.Res == "OK")
					{
						//alert("<?php echo $langs->trans("success_add_tmp")?>");
						location.href = '<?php echo $_SERVER['PHP_SELF'].'?id='.$id; ?>&tabq='+obj.temp;
					}
				    
				       
				},
				error: function() {
					//alert('error handling here');
				}
				});
		}
		else
		{
			alert("<?php echo $langs->trans("Please_select_tmp")?>");
		}
	}
</script>
<?php
} else {
	accessforbidden('', 0, 1);
}

// End of page
llxFooter();
$db->close();
