<?php 

$sql = "SELECT p.field, p.title, p.type ";
$sql .= " FROM of_quality_cust_cpy as p";
$sql .= " WHERE p.fk_muprof = ".$id;
$sql .= " AND p.unikey = '".$tabq."'";
$sql .= " AND p.origin_type = '".$object->element."'";
$sql .= " ORDER BY CAST(p.order AS UNSIGNED);";

//echo $sql;
$fields = array();
$resql = $db->query($sql);
if ($resql)
{
	$num = $db->num_rows($resql);		
	if ($num > 0)
	{
						
		$i = 0;
		while ($i < $num ) {
			$objt = $db->fetch_object($resql);
			if(isset($objt->field))
			{
				$fields[] = $objt;
			}
			$i++;
		}
	}
}

$f = 0;
$query = "select rowid, ";
foreach($fields as $key => $field)
{
	$query .= $field->field;
	
	if($field->type=="ck")
	{
		
	}
	$f++;
}


$sql = "SELECT p.* ";
$sql .= " FROM of_quality_cust as p";
$sql .= " WHERE p.fk_muprof = ".$id;
$sql .= " AND p.template = '".$tabq."'";
$sql .= " AND p.origin_type = '".$object->element."'";
$sql .= " ORDER BY p.rowid";

//echo $sql;
$userof = new User($db);
$values = array();
$resql = $db->query($sql);
if ($resql)
{
	$num = $db->num_rows($resql);		
	if ($num > 0)
	{
						
		$i = 0;
		while ($i < $num ) {
			$objt = $db->fetch_object($resql);
			if(isset($objt->fk_muprof))
			{
				$values[] = $objt;
			}
			$i++;
		}
	}
}

//echo "<pre>";
//print_r($fields);
if (!empty($fields))
{
		print '<div id="qualitysheet" style=" width:80vw; overflow-x:auto !important;">';
		print '<style>table.liste th, table.noborder th, table.noborder tr.liste_titre td, table.noborder tr.box_titre td, table.liste td, table.noborder td, div.noborder form div, table.tableforservicepart1 td, table.tableforservicepart2 td {
    padding: 7px 2px 7px 2px !important;
} table.noborder{font-size: 0.80em;}</style>';
		print '	<form  name="addquality" id="addquality" action="'.$_SERVER["PHP_SELF"].'?id='.$object->id.(($action != 'editline') ? '#addline' : '').'" method="POST">
    	<input type="hidden" name="token" value="' . newToken().'">
    	<input type="hidden" name="action" value="' . (($action != 'editline') ? 'addlinequality' : 'updatequality').'_v2">
    	<input type="hidden" name="mode" value="">
    	<input type="hidden" name="id" value="' . $id.'">
    	<input type="hidden" name="tabq" value="' . $tabq.'">
		<input type="hidden" name="fk_muprof" value="' . $id.'">
		<input type="hidden" name="backtopage" value="'.$backtopage.'">';
		

		if (!empty($conf->use_javascript_ajax)) {
			include DOL_DOCUMENT_ROOT.'/core/tpl/ajaxrow.tpl.php';
		}

			print '<table  id="tablelines" class="noborder noshadow" >';

			include('tpl/objectline_title.tpl.php');
			// Form to add new line
			if ($permissiontoaddquality && $action != 'selectlines')
			{
				if ($action != 'editline')
				{
					// Add products/services form
					$coldisplay = 0;
					include('tpl/objectline_create.tpl.php');
	
					$parameters = array();
					$reshook = $hookmanager->executeHooks('formAddObjectLine', $parameters, $object, $action); // Note that $action and $object may have been modified by hook
				}
			}
			
			foreach($values as $line)
			{
				$coldisplay = 0;
				if($action == 'editline' && $line->rowid == $lineid )
				{
					
					include('tpl/objectline_edit.tpl.php');
				}
				else {
					//include(DOL_DOCUMENT_ROOT.'/multiprodof/quality/tpl/objectline_view.tpl.php');
				}
			}
			
			include('tpl/objectline_title.tpl.php');
			//echo "<pre>";
			//print_r($values);
			foreach($values as $line)
			{
				$coldisplay = 0;
				if($action == 'editline' && $line->rowid == $lineid )
				{
					
					//include(DOL_DOCUMENT_ROOT.'/multiprodof/quality/tpl/objectline_edit.tpl.php');
				}
				else
				{
					include('tpl/objectline_view.tpl.php');
				}
			}

		

		if (!empty($values) || ( $permissiontoaddquality && $action != 'selectlines' && $action != 'editline'))
		{
			print '</table>';
		}
		print '</div>';
		

		print "</form>\n";
		print "</div>";
	}?>
<style>
	.imcheck, .imcan{cursor:pointer}
</style>

<script>
$(document).ready(function() {
	"use strict";
	//Init event
	
	$(".imcheck").on('click', function(){
		$(this).css('opacity', '1');
		$("#ca"+$(this).attr("raw")).css('opacity', '0.3');
		$("#"+$(this).attr("raw")).val("YES");
		//console.log($(this));
	});
	$(".imcan").on('click', function(){
		$(this).css('opacity', '1');
		$("#ck"+$(this).attr("raw")).css('opacity', '0.3');
		$("#"+$(this).attr("raw")).val("NO");
		//console.log($(this));
	}); 
	
	$("#addline").on('click', function(){
		CheckLine();
	});
	
	$("#savelinebutton").on('click', function(){
		CheckLine();
	});
	
	<?php if((($action == 'editline' && $line->rowid != "") || $tabq !="GENERAL" ) && !in_array($action, array('deletetemp','deletelinev2')))
	{?>
	setTimeout(function(){
	//$("#notes").focus();	
	var scrollDiv = document.getElementById("qualitysheet").offsetTop;
	window.scrollTo({ top: scrollDiv-70, behavior: 'smooth'});
}, 300);
	//document.getElementById("qualitysheet").scrollIntoView();
	<?php } ?>
	
}
);
CheckLine = function()
{
	var fail=0;
	var vales = document.querySelectorAll('.Checkid');
	for(vale of vales)//in es index of es para valor
	{
		if(vale.value=="")
		{
			fail++;
		}
	
	}
	if(fail>0)
	{
		alert("<?php echo $langs->trans("Por_favor_marque")?>");
	}
	else
	{
		if($("#addline").length > 0)
		{
			$("#addline").attr("type",'submit');
			$("#addline").click();
		}
		if($("#savelinebutton").length > 0)
		{
			$("#savelinebutton").attr("type",'submit');
			$("#savelinebutton").click();
		}
		
	}
}
</script>	
