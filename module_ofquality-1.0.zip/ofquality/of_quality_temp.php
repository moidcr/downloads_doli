<?php
/* Copyright (C) 2001-2005	Rodolphe Quiedeville	<rodolphe@quiedeville.org>
 * Copyright (C) 2004-2015	Laurent Destailleur		<eldy@users.sourceforge.net>
 * Copyright (C) 2005-2012	Regis Houssin			<regis.houssin@inodbox.com>
 * Copyright (C) 2015		Jean-François Ferry		<jfefe@aternatik.fr>
 * Copyright (C) 2019		Nicolas ZABOURI			<info@inovea-conseil.com>
 * Copyright (C) 2020		Pierre Ardoin			<mapiolca@me.com>
 * Copyright (C) 2020		Tobias Sekan			<tobias.sekan@startmail.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */

/**
 *	\file		htdocs/comm/index.php
 *	\ingroup	commercial
 *	\brief		Home page of commercial area
 */

// Load Dolibarr environment
$res = 0;
// Try main.inc.php into web root known defined into CONTEXT_DOCUMENT_ROOT (not always defined)
if (!$res && !empty($_SERVER["CONTEXT_DOCUMENT_ROOT"])) {
	$res = @include $_SERVER["CONTEXT_DOCUMENT_ROOT"]."/main.inc.php";
}
// Try main.inc.php into web root detected using web root calculated from SCRIPT_FILENAME
$tmp = empty($_SERVER['SCRIPT_FILENAME']) ? '' : $_SERVER['SCRIPT_FILENAME']; $tmp2 = realpath(__FILE__); $i = strlen($tmp) - 1; $j = strlen($tmp2) - 1;
while ($i > 0 && $j > 0 && isset($tmp[$i]) && isset($tmp2[$j]) && $tmp[$i] == $tmp2[$j]) {
	$i--; $j--;
}
if (!$res && $i > 0 && file_exists(substr($tmp, 0, ($i + 1))."/main.inc.php")) {
	$res = @include substr($tmp, 0, ($i + 1))."/main.inc.php";
}
if (!$res && $i > 0 && file_exists(dirname(substr($tmp, 0, ($i + 1)))."/main.inc.php")) {
	$res = @include dirname(substr($tmp, 0, ($i + 1)))."/main.inc.php";
}
// Try main.inc.php using relative path
if (!$res && file_exists("../main.inc.php")) {
	$res = @include "../main.inc.php";
}
if (!$res && file_exists("../../main.inc.php")) {
	$res = @include "../../main.inc.php";
}
if (!$res && file_exists("../../../main.inc.php")) {
	$res = @include "../../../main.inc.php";
}
if (!$res) {
	die("Include of main fails");
}
require_once DOL_DOCUMENT_ROOT.'/core/class/html.formfile.class.php';
require_once DOL_DOCUMENT_ROOT.'/core/lib/agenda.lib.php';
require_once DOL_DOCUMENT_ROOT.'/comm/action/class/actioncomm.class.php';
require_once DOL_DOCUMENT_ROOT.'/comm/propal/class/propal.class.php';
require_once DOL_DOCUMENT_ROOT.'/commande/class/commande.class.php';
require_once DOL_DOCUMENT_ROOT.'/contrat/class/contrat.class.php';
require_once DOL_DOCUMENT_ROOT.'/fourn/class/fournisseur.commande.class.php';
require_once DOL_DOCUMENT_ROOT.'/societe/class/client.class.php';
require_once DOL_DOCUMENT_ROOT.'/supplier_proposal/class/supplier_proposal.class.php';
require_once DOL_DOCUMENT_ROOT.'/core/lib/propal.lib.php';
require_once DOL_DOCUMENT_ROOT.'/core/lib/order.lib.php';

// Initialize technical object to manage hooks. Note that conf->hooks_modules contains array
$hookmanager = new HookManager($db);
$hookmanager->initHooks(array('wor_flow_commercialindex'));

// Load translation files required by the page
$langs->loadLangs(array("boxes", "commercial", "contracts", "orders", "propal", "supplier_proposal"));

$action = GETPOST('action', 'aZ09') ? GETPOST('action', 'aZ09') : 'edit' ;
$id = GETPOST('id', 'int');

// Securite acces client
$socid = GETPOST('socid', 'int');
if (isset($user->socid) && $user->socid > 0) {
	$action = '';
	$socid = $user->socid;
}

$max = $conf->global->MAIN_SIZE_SHORTLIST_LIMIT;
$now = dol_now();

// Security check
$socid = GETPOST("socid", 'int');

restrictedArea($user, 'societe', $id, '&societe', '', 'fk_soc', 'rowid', 0);

$maxofloop = (empty($conf->global->MAIN_MAXLIST_OVERLOAD) ? 500 : $conf->global->MAIN_MAXLIST_OVERLOAD);

if($action=="go_create")
{
	
	$title = GETPOST('title', 'alpha');
	$status = GETPOST('status', 'int');
	$sql = 'INSERT INTO of_quality_tmp_c';
	$sql .= ' (title, fk_user_author, datec, status';
	$sql .= ')';
	$sql .= " VALUES ('".$title."', ";
	$sql .= " '".$status."', ";
	$sql .= " NOW(), ";
	$sql .= " '".$status."' ";
	$sql .= ')';

	$resql = $db->query($sql);
	$id = $db->last_insert_id(MAIN_DB_PREFIX.'multiprodof_quality_tmp_c');
	setEventMessages($langs->trans('success_add_tmp'), null, 'mesgs');
	header('Location: '.$_SERVER["PHP_SELF"].'?id='.$id);
	exit();
}

if($action=="go_edit")
{
	$title = GETPOST('title', 'alpha');
	$status = GETPOST('status', 'int');
	
	$sql = "UPDATE of_quality_tmp_c";
	$sql .= " set status = '".$status."', title = '".$title."',  modified_by = '".$user->id."', modified_date = NOW() where rowid = '".$id."'";
	setEventMessages($langs->trans('success_update_tmp'), null, 'mesgs');
	$resql = $db->query($sql);
	$action = "edit";
}

if($action=="add_field")
{
	$sql = "SELECT max(p.order) as orderf";
	$sql .= " FROM of_quality_tmp_c_details as p";
	$sql .= " WHERE p.fk_temp = ".$id;
$fields = array();
	$resql = $db->query($sql);
	$obj = $db->fetch_object($resql);
	//echo $sql;
	$ord = 0;
	if($resql && $obj && isset($obj->orderf))
	{
		$ord = $obj->orderf+1;
	}	
	
	$typef = GETPOST('typef', 'alpha');
	$titlef = GETPOST('titlef', 'alpha');
	$sql = 'INSERT INTO of_quality_tmp_c_details';
	$sql .= ' (fk_temp, type, title, `order`';
	$sql .= ')';
	$sql .= " VALUES ('".$id."', ";
	$sql .= " '".$typef."', ";
	$sql .= " '".$titlef."', ";
	$sql .= " '".$ord."' ";
	$sql .= ')';

	$resql = $db->query($sql);
	$action = "edit";
	setEventMessages($langs->trans('success_add_field'), null, 'mesgs');
//exit;
}

if($action=="update_field")
{
	$typef = GETPOST('typef', 'alpha');
	$titlef = GETPOST('titlef', 'alpha');
	$line_id = GETPOST('line_id', 'alpha');
	
	$Resp["Res"] = "Error";
	$sql = "UPDATE of_quality_tmp_c_details";
	$sql .= " set type = '".$typef."', title = '".$titlef."' where rowid = '".$line_id."'";
	
	$resql = $db->query($sql);
	if($resql)
	{
		$Resp["Res"] = "OK";
	}

	echo json_encode($Resp);
	exit;

}

if($action=="delete_field")
{
	$line_id = GETPOST('line_id', 'alpha');
	
	$Resp["Res"] = "Error";
	$sql = "DELETE FROM of_quality_tmp_c_details";
	$sql .= " where rowid = '".$line_id."'";
	
	$resql = $db->query($sql);
	if($resql)
	{
		$Resp["Res"] = "OK";
	}

	echo json_encode($Resp);
	exit;

}

if($action=="sort_lines")
{
	$typef = GETPOST('typef', 'alpha');
	$titlef = GETPOST('titlef', 'alpha');
	$lines = GETPOST('lines', 'array');
	$Resp["Res"] = "Error";
	
	if(count($lines)>0)
	{
		foreach($lines as $ind => $line)
		{
			$sql = "UPDATE of_quality_tmp_c_details";
			$sql .= " set `order` = '".$ind."' where rowid = '".$line."'";
			$resql = $db->query($sql);
			
			echo $sql;
		}
	}
	
	$Resp["Res"] = "OK";

	echo json_encode($Resp);
	exit;

}
/*
 * Actions
 */

// None


/*
 * View
 */

$form = new Form($db);
$formfile = new FormFile($db);
$companystatic = new Societe($db);
if (!empty($conf->propal->enabled)) {
	$propalstatic = new Propal($db);
}
if (!empty($conf->supplier_proposal->enabled)) {
	$supplierproposalstatic = new SupplierProposal($db);
}
if (!empty($conf->commande->enabled)) {
	$orderstatic = new Commande($db);
}
if ((!empty($conf->fournisseur->enabled) && empty($conf->global->MAIN_USE_NEW_SUPPLIERMOD)) || !empty($conf->supplier_order->enabled)) {
	$supplierorderstatic = new CommandeFournisseur($db);
}

llxHeader("", $langs->trans("Templates_Of_quality"));

$sql = "SELECT p.rowid, p.title, p.status";
	$sql .= " FROM of_quality_tmp_c as p";
	$sql .= " WHERE p.rowid = ".$id;

	$resql = $db->query($sql);
	if ($resql) {
		$num = $db->num_rows($resql);
		
		$wfobj = $db->fetch_object($resql);
				
	}

$sql = "SELECT p.rowid, p.type, p.title";
	$sql .= " FROM of_quality_tmp_c_details as p";
	$sql .= " WHERE p.fk_temp = ".$id;
	$sql .= " ORDER BY p.order";
$fields = array();
	$resql = $db->query($sql);
	if ($resql) {
		$num = $db->num_rows($resql);
		
		if ($num > 0) {
			$i = 0;
		
			while ($i < $num ) {
				$obj = $db->fetch_object($resql);
				$fields[$obj->rowid] = $obj;
				$i++;
			}
		}
	}


print load_fiche_titre($langs->trans("Templates_Of_quality"), '', 'generic');
print '<hr>';
print '<div class="fichecenter2"><!--<div class="fichethirdleft">-->';
print '<form action="'.$_SERVER['PHP_SELF'].'?id='.$id.'" method="POST">'."\n";
print '<input type="hidden" name="token" value="'.newToken().'">';
print '<input type="hidden" name="action" value="go_'.$action.'">';
print '<input type="hidden" name="id" value="'.$id.'">';

print '<table class="border centpercent">';


			// Title
			print '<tr><td class="titlefieldcreate"><span id="TypeName" class="fieldrequired">'.$langs->trans('title_quality').'</span></td>';
			print '<td colspan="3"><input type="text" class="minwidth300" maxlength="128" name="title" id="title" value="'.$wfobj->title.'" autofocus="autofocus">';
		
			print '</td></tr>';
			
			// Status
			print '<tr><td class="titlefieldcreate"><span id="TypeName" class="fieldrequired">'.$langs->trans('Status').'</span></td>';
			print '<td colspan="3"><select class="flat minwidth100 maxwidthonsmartphone " name = "status" tabindex="-1" aria-hidden="true"><option value="1" '.($wfobj->status==="1" ? "selected" : "" ).' >'.$langs->trans('StatusWF_1').'</option><option value="0" '.($wfobj->status=="0" ? "selected" : "" ).'>'.$langs->trans('StatusWF_0').'</option></select>';
		
			print '</td></tr>';
			
print '</table>';
/*
			 * Action bar
			 */
			print '<div class="tabsAction">';
			print '<center>';
			$parameters = array();
			$reshook = $hookmanager->executeHooks('addMoreActionsButtons', $parameters, $object, $action); // Note that $action and $object may have been modified by hook
			if ($reshook < 0) {
				setEventMessages($hookmanager->error, $hookmanager->errors, 'errors');
			}

			print '<input type="submit" class="butAction" value="'.$langs->trans("Save").'">';		
			print '</form>';
			print '</center>';
			print "</div>\n";
			

if($action != "create")
{	
	print '<hr>';
	print '<br>';
	
	print '<form action="'.$_SERVER['PHP_SELF'].'?id='.$id.'" method="POST">'."\n";
						print '<input type="hidden" name="token" value="'.newToken().'">';
						print '<input type="hidden" name="action" value="add_field">';
						print '<input type="hidden" name="id" value="'.$id.'">';
						print '<table class="noborder centpercent">'."\n";
						print '<tr class="liste_titre"><td class=" liste_titre" >'.$langs->trans("Type").'</td>'."\n";
						
						print '<td class="titlefield liste_titre"><select class="flat minwidth100 maxwidthonsmartphone " name = "typef" tabindex="-1" aria-hidden="true">';
						
							print '<option value="ck" >'.$langs->trans("quality_ck").'</option>';
							print '<option value="nm" >'.$langs->trans("quality_nm").'</option>';
							print '<option value="tx" >'.$langs->trans("quality_tx").'</option>';
							print '<option value="nt" >'.$langs->trans("quality_nt").'</option>';
						
						print '</select></td>'."\n";
						
						print '<td class=" liste_titre" >'.$langs->trans("title_quality").'</td>'."\n";
						print '<td class="liste_titre">';
						print '<input type="text" name="titlef" placeholder = "'.$langs->trans("title_quality").'" value=""></td>';
						print '<input type="hidden" name="entity" value="'.$conf->entity.'">';
						print '<td class="liste_titre">';
						print '<input type="submit" class="button buttongen button-add" value="'.$langs->trans("Add").'">';
						print '</td></tr>'."\n";
						print '</table>';
						print '</form>';
						
				print '<hr><br>';
				
				print '<div class="div-table-responsive-no-min">';
				print '<table  id="tablelines" class="noborder centpercent">';
				print '<tbody>';
				print '<tr class="liste_titre">';
				print '<th ># '.$langs->trans('Type').'</th>';
				print '<th >'.$langs->trans('title_quality').'</th>';
				print '<th colspan="3"  width="1%" align="center">'.$langs->trans('options_quality').'</th>';
	
				print '</tr>';
				

				foreach($fields as $field) {
					
					
	
					print '<tr class="oddeven" id="tr'.$field->rowid.'" lineid="'.$field->rowid.'">';
					print '<td class="nowrap tdoverflowmax100"><select class="flat minwidth100 maxwidthonsmartphone " id="typef'.$field->rowid.'" tabindex="-1" aria-hidden="true">';
						
							print '<option value="ck" '.($field->type=="ck" ? "selected" : "").' >'.$langs->trans("quality_ck").'</option>';
							print '<option value="nm" '.($field->type=="nm" ? "selected" : "").'>'.$langs->trans("quality_nm").'</option>';
							print '<option value="tx" '.($field->type=="tx" ? "selected" : "").'>'.$langs->trans("quality_tx").'</option>';
							print '<option value="nt" '.($field->type=="nt" ? "selected" : "").'>'.$langs->trans("quality_nt").'</option>';
						
					print '</select></td>';
					print '<td class="nowrap tdoverflowmax100"><input type="text" id="titlef'.$field->rowid.'" placeholder = "'.$langs->trans("title").'" value="'.$field->title.'"></td>';
					
					print '
					
					<td>
					<a class="editfielda " href="javascript:savel('.$field->rowid.')">
		<span class="fas fa-save" style=" color: #444;" title="Modificar"></span></a>
					</td>
					
					<td class="linecoldelete center"><a class="deletea" href="javascript:deletel('.$field->rowid.')"><span class="fas fa-trash pictodelete" style="" title="Eliminar"></span></a></td>
					
					
					
					<td class="linecolmove tdlineupdown center">			<a class="lineupdown" href="/plast/compta/facture/card.php?id=144&amp;action=up&amp;rowid=1388">
						<span class="fas fa-caret-up imgup imgupforline" style="" title="Up"></span>			</a>
								<a class="lineupdown" href="/plast/compta/facture/card.php?id=144&amp;action=down&amp;rowid=1388">
						<span class="fas fa-caret-down imgdown imgdownforline" style="" title="Down"></span>			</a>
					</td>';
					
					print "</tr>\n";
				}
				
				print '</table>';
					
				
}				
				
				print '</div>';




print '</div>';?>
<!-- BEGIN PHP TEMPLATE AJAXROW.TPL.PHP - Script to enable drag and drop on lines of a table -->
<script>
$(document).ready(function(){
	$(".imgupforline").hide();
	$(".imgdownforline").hide();
    $(".lineupdown").removeAttr('href');
    $(".tdlineupdown").css("background-image",'url(/plast/theme/eldy/img/grip.png)');
    $(".tdlineupdown").css("background-repeat","no-repeat");
    $(".tdlineupdown").css("background-position","center center");

    console.log("Prepare tableDnd for #tablelines");
    $("#tablelines").tableDnD({
		onDrop: function(table, row) {
			var reloadpage = "0";
			console.log("tableDND onDrop");
			console.log(decodeURI($("#tablelines").tableDnDSerialize()));
			$('#tablelines tr[data-element=extrafield]').attr('id', '');	// Set extrafields id to empty value in order to ignore them in tableDnDSerialize function
			var Lines = GetCurrOrder();
			$.post("<?php echo $_SERVER['PHP_SELF'].'?id='.$id; ?>",
			{
				action: "sort_lines",
				id: "<?php echo $id;?>",
				lines: Lines,
				token: '<?php echo currentToken(); ?>'
			},
			function() {
				console.log("tableDND end of ajax call");
				if (reloadpage == 1) {
					//console.log(' - /plast/compta/facture/card.php - facid=144');
					location.href = '/plast/compta/facture/card.php?facid=144';
				} 
				else {
					$("#tablelines .drag").each(
						function( intIndex ) {
							// $(this).removeClass("pair impair");
							//if (intIndex % 2 == 0) $(this).addClass('impair');
							//if (intIndex % 2 == 1) $(this).addClass('pair');
						});
						}
			});
		},
		onDragClass: "dragClass",
		dragHandle: "td.tdlineupdown"
	});
    $(".tdlineupdown").hover( function() { $(this).addClass('showDragHandle'); },
    	function() { $(this).removeClass('showDragHandle'); }
    );
});

function GetCurrOrder()
{
	var Lines = [];
	if($("#tablelines").length > 0)
	{
		//console.log("====>||");
		if($("#tablelines tr.oddeven").length > 0)
		{
			var lb = 0;
			for(var tr of $("#tablelines tr.oddeven"))
			{
				Lines[lb] = $(tr).attr("lineid");
				lb++;
			}
		}
	}
	console.log("Linesss");
	console.log(Lines);
	return Lines;
}
</script>
<!-- END PHP TEMPLATE AJAXROW.TPL.PHP -->
<script>


function savel(ln)
{
	
	var Tit = $("#titlef"+ln).val();
	var Typ = $("#typef"+ln).val();
	if(Tit!="")
	{
		$.ajax({
			type: "POST",
			url: "<?php echo $_SERVER['PHP_SELF'].'?id='.$id; ?>",
			data: { token: '<?php echo currentToken(); ?>', action: "update_field", line_id: ln, titlef: Tit, typef: Typ },
			success: function(data, status, xhr) {
				var obj = JSON.parse(data); //if the dataType is not specified as json uncomment this
				if(obj.Res == "OK")
				{
					alert("<?php echo $langs->trans("success_update")?>");
				}
			    
			       
			},
			error: function() {
				//alert('error handling here');
			}
			});
	}
	else
	{
		alert("<?php echo $langs->trans("Please_title")?>");
	}
}

function deletel(ln)
{
	
	if(ln!="")
	{
		$.ajax({
			type: "POST",
			url: "<?php echo $_SERVER['PHP_SELF'].'?id='.$id; ?>",
			data: { token: '<?php echo currentToken(); ?>', action: "delete_field", line_id: ln },
			success: function(data, status, xhr) {
				var obj = JSON.parse(data); //if the dataType is not specified as json uncomment this
				if(obj.Res == "OK")
				{
					$("#tr"+ln).remove();
					alert("<?php echo $langs->trans("success_delete")?>");
				}
			    
			       
			},
			error: function() {
				//alert('error handling here');
			}
			});
	}
	else
	{
		alert("<?php echo $langs->trans("Error_delete")?>");
	}
}
</script>
<?php

$parameters = array('user' => $user);
$reshook = $hookmanager->executeHooks('work_flow_actions', $parameters, $object); // Note that $action and $object may have been modified by hook

// End of page
llxFooter();
$db->close();
