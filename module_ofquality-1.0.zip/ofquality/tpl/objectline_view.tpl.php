<?php
/* Copyright (C) 2010-2013	Regis Houssin		<regis.houssin@inodbox.com>
 * Copyright (C) 2010-2011	Laurent Destailleur	<eldy@users.sourceforge.net>
 * Copyright (C) 2012-2013	Christophe Battarel	<christophe.battarel@altairis.fr>
 * Copyright (C) 2012       Cédric Salvador     <csalvador@gpcsolutions.fr>
 * Copyright (C) 2012-2014  Raphaël Doursenaud  <rdoursenaud@gpcsolutions.fr>
 * Copyright (C) 2013		Florian Henry		<florian.henry@open-concept.pro>
 * Copyright (C) 2017		Juanjo Menent		<jmenent@2byte.es>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 *
 * Need to have following variables defined:
 * $object (invoice, order, ...)
 * $conf
 * $langs
 * $forceall (0 by default, 1 for supplier invoices/orders)
 * $element     (used to test $user->rights->$element->creer)
 * $permtoedit  (used to replace test $user->rights->$element->creer)
 * $inputalsopricewithtax (0 by default, 1 to also show column with unit price including tax)
 * $object_rights->creer initialized from = $object->getRights()
 * $disableedit, $disablemove, $disableremove
 *
 * $type, $text, $description, $line
 */

// Protection to avoid direct call of template
if (empty($object) || !is_object($object))
{
	print "Error, template page can't be called as URL";
	exit;
}


/*global $forceall, $senderissupplier, $inputalsopricewithtax, $outputalsopricetotalwithtax;

if (empty($dateSelector)) $dateSelector = 0;
if (empty($forceall)) $forceall = 0;
if (empty($senderissupplier)) $senderissupplier = 0;
if (empty($inputalsopricewithtax)) $inputalsopricewithtax = 0;
if (empty($outputalsopricetotalwithtax)) $outputalsopricetotalwithtax = 0;

// add html5 elements
$domData  = ' data-element="'.$line->element.'"';
$domData .= ' data-id="'.$line->id.'"';
$domData .= ' data-qty="'.$line->qty.'"';
$domData .= ' data-product_type="'.$line->product_type.'"';*/



print "<!-- BEGIN PHP TEMPLATE objectline_view.tpl.php -->\n";


print '<tr id="row-'.$line->id.'" class="drag drop oddeven"  >';
$sel='<table><tr><td @stylec@ ><img width="18" class="imcheck" id="ck@@" title="@@" raw="@@" src="img/check.png"/></td> <td @stylex@><img width="18" class="imcan" title="@@" id="ca@@" raw="@@" @stylex@ src="img/cancel.png"/></td><tr></table>';



foreach($fields as $key => $field)
{
	$coldisplay++;
	if($field->type=="ck")
	{
		$sal = str_replace("@@", $field->field, $sel);
		if($line->{$field->field} == "YES")
		{
			$sal = str_replace("@stylec@", "", $sal);
			$sal = str_replace("@stylex@", 'style="display:none"', $sal);
		}
		else
		{
			$sal = str_replace("@stylec@", 'style="display:none"', $sal);
			$sal = str_replace("@stylex@", "", $sal);
		}
		
		print '<td valign="top" align="center" class=" borderbottom">'.$sal;
		print '</td>';
	}
	elseif($field->type=="nm") {
		$coldisplay++;
		print '<td valign="top" align="center" class=" borderbottom"><input type="number" disabled  name="'.$field->field.'" id="'.$field->field.'" class="flat right" size="5" value="'.$line->{$field->field}.'">';
		print '</td>';
	}
	elseif($field->type=="tx") {
		$coldisplay++;
		print '<td valign="top" align="center" class=" borderbottom">'.$line->{$field->field}.'</td>';
	}
	elseif($field->type=="nt")
	{
		print '<td valign="top" class=" borderbottom">'.$line->{$field->field}."</td>";
	}
}


$coldisplay++;
print '<td valign="top" align="center" class=" borderbottom">';

print '<table><tr>';
print '<td>';
print '<div style="text-align:right">';
if (!empty($permissiontoeditquality)) {
		print '<a class="editfielda reposition" href="'.$_SERVER["PHP_SELF"].'?id='.$object->id.'&amp;action=editline&tabq='.$tabq.'&amp;lineid='.$line->rowid.'">'.img_edit().'</a> ';
		}
if ($permissiontoaddquality) {
			print'<a class="reposition" href="'.$_SERVER["PHP_SELF"].'?id='.$object->id.'&amp;action=deletelinev2&tabq='.$tabq.'&amp;token='.newToken().'&amp;lineid='.$line->rowid.'">';
			print img_delete();
			print '</a>';
		}
print'&nbsp;<a class="reposition" href="#" title="'.dol_print_date($line->date_creation,'dayrfc')." ".dol_print_date($line->date_creation,'hour').'">';
			print '<i class="fas fa-clock"></i>';
			print '</a>';
print '</div>';
print '</td>';
print '<td>';

$userof->fetch($line->fk_user_creat);
$line->fk_user_creat = $userof->getNomUrl(1, '', 0, 0, 24, 0, 'login');
print $line->fk_user_creat;
print '</td>';
print '</tr></table>';

print '</td>';

	
	print '</tr>';
	
print "<!-- END PHP TEMPLATE objectline_view.tpl.php -->\n";
